#!/bin/bash
# Rebuild BURN_Recon.html from the modules in src/, then syntax-check every
# script block individually.
#
# v3.24.9+ FAST-BOOT: the six app modules are emitted as
#   <script type="text/plain" class="deferred-app">
# so the browser does NOT parse ~1.4 MB of JavaScript before the sign-in screen
# paints. A small bootstrap appended at the end concatenates those blocks in
# order and runs them as one classic script on the first animation frame —
# identical globals, identical order, only the timing changes.
set -e
OUT="${1:-BURN_Recon.html}"
D="$(dirname "$0")/src"
{
  cat "$D/01_head.html"
  for f in 02_bom_core.js 03_fflate.min.js 04_xlsx_read.js 05_xlsx_write.js 06_pdf_write.js 07_app.js; do
    printf '<script type="text/plain" class="deferred-app">\n'; cat "$D/$f"; printf '\n</script>\n'
  done
  cat << 'BOOT'
<script>
/* ---- fast-boot: compile the deferred app after the gate paints ---- */
(function(){
  var done=false;
  function startApp(){
    if(done) return; done=true;
    var ge=document.getElementById('gateErr');
    try{
      var blocks=document.querySelectorAll('script.deferred-app'), code='';
      for(var i=0;i<blocks.length;i++){ code += blocks[i].textContent + '\n;\n'; }
      var s=document.createElement('script');
      s.textContent=code;
      document.body.appendChild(s);
    }catch(e){
      if(ge){ ge.style.color='#ffb4a2';
        ge.textContent='The app could not start on this machine - please reload the page.'; }
      if(window.console&&console.error) console.error('deferred-app start failed',e);
      var b0=document.querySelector('.gsubmit'); if(b0) b0.disabled=false;
      return;
    }
    var b=document.querySelector('.gsubmit'); if(b) b.disabled=false;
    if(ge && ge.textContent==='Preparing\u2026') ge.textContent='';
    var uf=document.getElementById('userName')||document.getElementById('pw'); if(uf){ try{ uf.focus(); }catch(_){ } }
  }
  var b=document.querySelector('.gsubmit'); if(b) b.disabled=true;
  var ge=document.getElementById('gateErr'); if(ge && !ge.textContent) ge.textContent='Preparing\u2026';
  if(window.requestAnimationFrame){ requestAnimationFrame(function(){ setTimeout(startApp,0); }); }
  else { setTimeout(startApp,0); }
  window.addEventListener('load', function(){ setTimeout(startApp,0); });
})();
</script>
</body>
</html>
BOOT
  if [ -f "$D/08_tail.html" ]; then cat "$D/08_tail.html"; fi
} > "$OUT"
echo "built $OUT ($(wc -c < "$OUT") bytes)"

python3 - "$OUT" << 'PY'
import re,subprocess,sys,tempfile,os
h=open(sys.argv[1]).read()
blocks=re.findall(r'<script type="text/plain" class="deferred-app">(.*?)</script>', h, re.S)
bad=0
for i,b in enumerate(blocks):
    p=os.path.join(tempfile.gettempdir(), f"blk{i}.js")
    open(p,"w").write(b)
    r=subprocess.run(["node","--check",p],capture_output=True,text=True)
    print(f"  block {i}: {len(b):7} chars  {'OK' if r.returncode==0 else 'SYNTAX ERROR'}")
    if r.returncode:
        bad+=1; print("     "+"\n     ".join(r.stderr.strip().split("\n")[:4]))
# also check the concatenation parses as one unit (what the browser runs)
p=os.path.join(tempfile.gettempdir(),"concat.js"); open(p,"w").write("\n;\n".join(blocks))
r=subprocess.run(["node","--check",p],capture_output=True,text=True)
print("  concatenated:", "OK" if r.returncode==0 else "SYNTAX ERROR")
if r.returncode: bad+=1
if len(blocks)!=6:
    print(f"  WARNING: expected 6 deferred-app blocks, found {len(blocks)}"); bad+=1
sys.exit(1 if bad else 0)
PY
echo "all blocks parse"
