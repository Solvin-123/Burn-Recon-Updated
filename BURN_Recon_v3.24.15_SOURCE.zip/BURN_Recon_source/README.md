# BURN Recon — Source

**Version 1.9.6** · Burn Manufacturing · Solvin, Operations / Manufacturing Engineering

This is the complete source for BURN Recon. Nothing is minified, compiled or obfuscated — the shipped `BURN_Recon_v1.9.6.html` is these files concatenated, and that single file is the whole application.

---

## Layout

```
BURN_Recon_source/
├── build.sh              rebuild the single HTML file, then syntax-check it
└── src/
    ├── 01_head.html      markup, CSS, every tab and panel        138 KB
    ├── 02_bom_core.js    the comparison engine                    57 KB
    ├── 03_fflate.min.js  zip/unzip (MIT, third party)             32 KB
    ├── 04_xlsx_read.js   .xlsx reader                              4 KB
    ├── 05_xlsx_write.js  .xlsx writer                              8 KB
    ├── 06_pdf_write.js   .pdf writer                              16 KB
    └── 07_app.js         UI, state, persistence, reports         265 KB
```

## Building

```bash
./build.sh                     # writes BURN_Recon.html
./build.sh /path/to/output.html
```

The script concatenates the modules and then **syntax-checks every script block individually**. Do not replace that with a single check over the whole file: a concatenation of six blocks can parse cleanly while one block is broken, and that is exactly how a fatal syntax error once shipped. It also warns if the block count is not 6.

Requires `node` for the syntax check and `python3` for the checker. Neither is needed to *run* the application.

---

## Architecture

**No build step is required to run it, and there is no framework.** Plain JavaScript, one global state object, full re-render on change.

### `02_bom_core.js` — the engine
A dependency-free module exposed as `window.BOM` (and as a CommonJS export, so it can be unit-tested in Node without a browser). It contains no DOM code at all. Key entry points:

| Function | Purpose |
|---|---|
| `findHeaderRow`, `tableToObjects`, `autoMap`, `applyMap` | ingest a NAV export and map its columns |
| `prepare` | normalise rows, aggregate a material used across sub-assemblies |
| `compareBoM` | the comparison itself — returns one row per item with flags |
| `health` | score the audit across coverage, utilization, identity, drawing |
| `tpdStatus`, `tpdSummary`, `ecnImpact` | deviation and change-notice state |
| `familyKey`, `familyPairKey`, `familyCompare` | same-family reconciliation |
| `buildChangeList` | the corrective actions to apply in NAV |
| `DEFAULTS` | every threshold and policy in one object |

**This is the file to read first.** If you only understand one module, understand this one — everything else is presentation.

### `07_app.js` — everything else
State (`S`), persistence to `localStorage`, all rendering, all reports, auth, the people directory and rights. Functions are grouped by tab and named `render<Tab>`.

Two things to know before editing:

1. **The render chain.** `recompute()` calls `renderBatch()`, which calls every `render*` function. It appears in **two** places — a normal path and an early return when nothing is comparable. A new renderer must be added to **both** or it will silently never run on one path. This has caused several defects.
2. **Focus.** Tables with editable cells must not re-render on every keystroke, or the cursor is thrown out of the input. Either use the `captureFocus`/`restoreFocus` pair, or do not re-render on `input` — see `setPerson` for the latter approach.

### Writers
`05_xlsx_write.js` emits OOXML directly; `06_pdf_write.js` emits PDF 1.4 with Helvetica and an embedded JPEG logo. Both are self-contained so the application needs no network access. The PDF writer counts byte offsets, not character offsets — do not "simplify" that, it is required for the embedded image and for any non-ASCII text.

---

## Storage keys

All state lives in `localStorage` under these keys:

| Key | Contents |
|---|---|
| `burn.bom.compare.v8` | products, floor records, registers, materials, filters |
| `burn.recon.perms` | rights granted to all users, extra admin names |
| `burn.recon.people` | the people directory, including password hashes |
| `burn.recon.ecnreview` | per-product ECN review decisions |
| `burn.recon.pw` | shared admin and user password hashes |
| `burn.recon.voice`, `burn.recon.voicename`, `burn.recon.tour`, `burn.recon.lite` | preferences |

Passwords are SHA-256 via `crypto.subtle`, never stored in plain text. **This is workflow separation, not security** — the file is local and editable. Real access control needs hosting and SSO.

---

## Conventions worth keeping

- **Nothing is a finding until the audit says so.** A loaded BoM is assumed correct; a difference is recorded only when someone amends it. Do not add checks that flag untouched data.
- **NAV net is the baseline.** NAV holds no scrap allowance, so excess consumption is reported as scrap to propose back to NAV — never silently added to the expected quantity.
- **The item number is the drawing number**, and a trailing letter is the revision (`11090D` = family 11090, revision D).
- **Reports carry no system name** — the generated Excel and PDF are Burn documents, not tool output.
- **One constant, one place.** The version, thresholds and labels each live in exactly one place. Values duplicated by hand have drifted out of sync three times.

---

## If this becomes a hosted application

The comparison engine ports unchanged — it is pure functions over plain objects, with no DOM or browser dependency. What needs writing is:

1. A back end holding the ten entities currently in `localStorage`, in PostgreSQL or MySQL
2. Session handling and SSO in place of the local password gate
3. A scheduled job for TPD expiry alerts by email
4. Touch-optimised floor entry screens, so capture happens at the line on a phone

`02_bom_core.js` can be required directly in Node today and unit-tested against real exports without a browser. That is the intended migration path, and the reason the engine has no UI code in it.

---

*Make It Right, Fix It*
