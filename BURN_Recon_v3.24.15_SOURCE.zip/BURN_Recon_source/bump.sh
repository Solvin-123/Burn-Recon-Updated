#!/bin/bash
# Bump the version. Uses a pattern that cannot silently miss, and verifies
# afterwards - four releases shipped mislabelled because a fixed-string sed
# matched nothing and failed quietly.
set -e
V="$1"
[ -z "$V" ] && { echo "usage: ./bump.sh 2.25.1"; exit 1; }
python3 - "$V" << 'PY'
import re,sys
v=sys.argv[1]; p="src/07_app.js"
s=open(p).read()
new,n=re.subn(r'const APP_VER="[0-9.]+"', f'const APP_VER="{v}"', s)
if n!=1: raise SystemExit(f"expected 1 APP_VER, found {n} - aborting")
open(p,"w").write(new)
print(f"APP_VER set to {v}")
PY
grep -o 'APP_VER="[0-9.]*"' src/07_app.js
