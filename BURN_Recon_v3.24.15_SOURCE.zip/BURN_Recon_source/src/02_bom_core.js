
/* ==========================================================================
 * BoM Integrity core  v4
 * BASELINE COMPARISON:  NAV-ERP BoM  <->  Actual BoM noted on the Production Floor
 * Highlights: material/description, part number, dosage, UoM, drawing revision,
 * and items missing from either side. Produces a corrective-action register.
 * Browser + Node, no dependencies.
 * ========================================================================== */
(function (root) {
  "use strict";

  const DEFAULTS = {
    join_key: "material_number",
    scope: {
      exclude_first_row: true,      // a NAV SoM export is headed by the finished good
      allowed_types: ["item"],      // drop routing rows (Machine / Work Center)
      exclude_replenishment: [],
      aggregate_duplicates: true,   // one material used under several sub-assemblies
    },
    uom: {
      mass:   { base:"g",  factors:{ mg:.001,g:1,gm:1,gram:1,grams:1,kg:1000,kgs:1000,kilogram:1000,t:1e6,ton:1e6 } },
      count:  { base:"ea", factors:{ ea:1,each:1,pc:1,pcs:1,piece:1,unit:1,nos:1,no:1 } },
      volume: { base:"ml", factors:{ ml:1,l:1000,ltr:1000,litre:1000,liter:1000 } },
      length: { base:"mm", factors:{ mm:1,cm:10,m:1000,in:25.4,inch:25.4 } },
      other:  { base:"unit", factors:{ rolls:1,roll:1,set:1,sets:1,pair:1,sec:1,hr:1,hrs:1 } },
    },
    dosage: { exact_rel:0.001, warning_rel:0.02 },
    // The scrap factor is a property of the PRODUCTION (floor) BoM. The NAV BoM
    // carries no scrap allowance, so expected consumption = NAV net x (1 + scrap%).
    scrap:  { default_pct:1.5, plausible_ceiling_pct:25, gap_threshold_pp:1 },
    drawing: {
      // At Burn the item number is the part number, and the part number is the
      // drawing number. A trailing letter on it is the revision, so 11090D is
      // drawing family 11090 at revision D.
      item_is_drawing: true,
      derive_from_description: true,
      rev_pattern: "\\bRev\\.?\\s*([A-Za-z0-9]+)\\b",
      code_pattern: "\\b(K(?:E[_ ]?)?CA[0-9]+(?:\\.[0-9]+)*)\\b",
    },
    checks: { description:true, part_number:true, drawing_rev:true, detect_substitution:true },
    tpd: { warn_days:2 },
    // Products sharing a model code are one family. Parts, drawings and their
    // utilization must match across the family; only the variant items below differ.
    family: { util_tolerance_rel:0.001,
      variant_words:["label","leaflet","warranty","manual","booklet","serial","sticker",
        "box","carton","packaging","tape","strap","polybag","bag","insert","barcode",
        "nameplate","decal","print","artwork","instruction"] },     // alert the admin this many days before a TPD expires
    health: { w_coverage:0.35, w_dosage:0.35, w_identity:0.15, w_drawing:0.15, grade_bands:{A:95,B:85,C:70,D:50} },
  };

  const LOGICAL_FIELDS = ["material_number","part_number","description","quantity",
    "quantity_uom","scrap_pct","drawing_no","drawing_rev","row_type","replenishment","line_cost"];

  const ALIASES = {
    material_number: ["material no","material number","no.","no","no_","item no.","item no","item no_","item","material","component no","component"],
    part_number:     ["part number","part no","part no.","vendor item no.","vendor item no"],
    /* The BoM already carries what each line costs for one unit of the product.
       Reading it here means the cost of everything the system reports comes from
       the same upload as the quantities, instead of a separate list kept by hand
       that was never complete. */
    line_cost:       ["total cost","total cost (lcy)","total cost lcy","line cost","cost","amount",
                      "unit cost","material cost","extended cost","value"],
    description:     ["component description","description","desc","name","item description","material description"],
    quantity:        ["utilization","actual utilization","qty. per top item","qty per top item","qty per fg","quantity per",
                      "qty. per bom line","qty per bom line","qty. per parent","qty per parent",
                      "quantity","qty","qty per","consumption","actual qty","observed qty"],
    quantity_uom:    ["unit of measure code","qty uom","uom","unit of measure","qty unit","bom unit of measure code"],
    scrap_pct:       ["scrap %","scrap%","scrap pct","scrap percent","scrap percentage","scrap factor","scrap"],
    drawing_no:      ["drawing no","drawing no.","drawing","drawing number","dwg","dwg no"],
    drawing_rev:     ["drawing rev","rev","revision","drawing revision","rev.","rev used"],
    row_type:        ["type","line type","row type"],
    replenishment:   ["replenishment system","replenishment","source","procurement"],
    /* The headings a NAV BoM export actually writes. Without these an untouched
       export mapped nothing: no item column, so no line had a key and nothing
       could be priced or compared. */
    /* The cost of the line for one unit of the product. This was listed as a
       logical field and given a label in the mapping panel, but never given any
       aliases — so autoMap could not find it whatever the column was called, and
       every value in the system read as not priced until somebody mapped it by
       hand. "Total Cost" is what the NAV BoM export calls it. */
    line_cost:       ["total cost","line cost","cost","extended cost","amount","line amount",
                      "cost amount","total","value","line value","unit cost","cost per unit",
                      "material cost","std cost","standard cost"],
  };

  /* ---------------- primitives ---------------- */
  function toFloat(v){
    if(v===null||v===undefined) return null;
    if(typeof v==="number") return isNaN(v)?null:v;
    const s=String(v).replace(/,/g,"").trim().toLowerCase();
    if(["","nan","none","null","na","n/a","-"].includes(s)) return null;
    const n=Number(s); return isNaN(n)?null:n;
  }
  function text(v){
    if(v===null||v===undefined) return "";
    if(typeof v==="number"&&isNaN(v)) return "";
    return String(v).trim();
  }
  function low(v){ return text(v).toLowerCase(); }
  function uomDimension(unit,uom){
    if(unit===null||unit===undefined) return [null,null];
    const u=low(unit);
    for(const dim in uom){ const f=uom[dim].factors;
      if(Object.prototype.hasOwnProperty.call(f,u)) return [dim,f[u]]; }
    return [null,null];
  }
  function relDiff(a,b){
    if(a===null||a===0||b===null) return (a===b)?null:Infinity;
    return Math.abs(a-b)/Math.abs(a);
  }
  function signedDiff(a,b){            // + means FLOOR consumes more than NAV
    if(a===null||b===null||a===0) return null;
    return (b-a)/Math.abs(a);
  }
  function normQty(row,uom){
    const q=toFloat(row.quantity);
    const [dim,factor]=uomDimension(row.quantity_uom,uom);
    if(q===null) return [null,dim];
    if(factor===null) return [null,"UNKNOWN"];
    return [q*factor,dim];
  }
  function drawingFamily(no){ return text(no).replace(/[A-Za-z]+$/,"").trim(); }
  function revFromNumber(no){ const m=/([A-Za-z])$/.exec(text(no)); return m?m[1].toUpperCase():""; }
  function deriveDrawing(row,cfg){
    const d=cfg.drawing;
    let no=text(row.drawing_no), rev=text(row.drawing_rev);
    // the part number carries the drawing identity and its revision
    if(!no&&d.item_is_drawing!==false) no=text(row.material_number);
    if(!rev&&no) rev=revFromNumber(no);
    if((!no||!rev)&&d.derive_from_description){
      const desc=text(row.description);
      if(!rev&&d.rev_pattern){ const m=new RegExp(d.rev_pattern).exec(desc); if(m) rev=m[1].toUpperCase(); }
      if(!no&&d.code_pattern){ const m=new RegExp(d.code_pattern).exec(desc); if(m) no=m[1]; }
    }
    return { no, rev, family:drawingFamily(no) };
  }

  /* ---------------- scoping + aggregation ---------------- */
  function prepare(rows,cfg){
    const sc=cfg.scope, uom=cfg.uom;
    const dropped={ first_row:0, type:0, replenishment:0, no_key:0 };
    let work=rows.slice();
    if(sc.exclude_first_row&&work.length){ work=work.slice(1); dropped.first_row=1; }
    if(sc.allowed_types&&sc.allowed_types.length){
      const allow=sc.allowed_types.map(low);
      work=work.filter(r=>{ const t=low(r.row_type);
        if(t===""||allow.includes(t)) return true; dropped.type++; return false; });
    }
    if(sc.exclude_replenishment&&sc.exclude_replenishment.length){
      const bad=sc.exclude_replenishment.map(low);
      work=work.filter(r=>{ if(bad.includes(low(r.replenishment))){ dropped.replenishment++; return false; } return true; });
    }
    work=work.filter(r=>{ if(text(r[cfg.join_key])===""){ dropped.no_key++; return false; } return true; });

    const groups=new Map();
    for(const r of work){
      const k=text(r[cfg.join_key]);
      const key=sc.aggregate_duplicates?k:(k+"\u0000"+groups.size);
      const dw=deriveDrawing(r,cfg);
      const [q,dim]=normQty(r,uom);
      if(!groups.has(key)){
        groups.set(key,{ material_number:k, description:text(r.description),
          part_number:text(r.part_number), drawing_no:dw.no, drawing_rev:dw.rev,
          replenishment:text(r.replenishment), row_type:text(r.row_type),
          drawing_family:dw.family,
          quantity_uom:text(r.quantity_uom), qty:toFloat(r.quantity), qty_base:q, dim,
          scrap_pct:toFloat(r.scrap_pct), line_cost:toFloat(r.line_cost), lines:1,
          parts:[toFloat(r.quantity)], uom_conflict:false });
      } else {
        const g=groups.get(key); g.lines++;
        if(low(g.quantity_uom)!==low(r.quantity_uom)) g.uom_conflict=true;
        g.qty=(g.qty||0)+(toFloat(r.quantity)||0);
        (g.parts=g.parts||[]).push(toFloat(r.quantity));
        if(q!==null) g.qty_base=(g.qty_base||0)+q;
        if(!g.drawing_no&&dw.no) g.drawing_no=dw.no;
        if(!g.drawing_rev&&dw.rev) g.drawing_rev=dw.rev;
        if(!g.part_number&&text(r.part_number)) g.part_number=text(r.part_number);
        if(g.scrap_pct===null&&toFloat(r.scrap_pct)!==null) g.scrap_pct=toFloat(r.scrap_pct);
        // a cost is a value per line, so aggregating lines adds them
        if(toFloat(r.line_cost)!==null) g.line_cost=(g.line_cost||0)+toFloat(r.line_cost);
      }
    }
    return { items:Array.from(groups.values()), dropped, inputRows:rows.length };
  }

  /* ================= THE BASELINE COMPARISON =================
     NAV-ERP BoM  vs  Actual BoM noted on the Production Floor           */
  const HARD = ["MISSING_ON_FLOOR","MISSING_IN_NAV","DOSAGE_MISMATCH","PARTNO_MISMATCH",
                "UOM_MISMATCH","UOM_UNKNOWN","UOM_CONFLICT","REV_MISMATCH",
                "DRAWING_NO_MISMATCH","SUBSTITUTION"];
  const DRAWING_FLAGS = ["DRAWING_NO_MISMATCH","REV_MISMATCH"];
  // Nothing has gone wrong on these rows — the audit simply has not reached them.
  const CAPTURE_FLAGS = [];   // nothing is "awaiting capture": unamended = correct

  function compareBoM(navItems,flrItems,cfg,scrapOverrides){
    const tol=cfg.dosage, ck=cfg.checks;
    // guard the scrap policy: a blank or zero ceiling would silently switch off
    // scrap detection altogether, which is never what anyone means.
    const scRaw=cfg.scrap||{};
    const sc={ default_pct: (toFloat(scRaw.default_pct)===null?DEFAULTS.scrap.default_pct:toFloat(scRaw.default_pct)),
      plausible_ceiling_pct: (toFloat(scRaw.plausible_ceiling_pct)||DEFAULTS.scrap.plausible_ceiling_pct),
      gap_threshold_pp: (toFloat(scRaw.gap_threshold_pp)||DEFAULTS.scrap.gap_threshold_pp) };
    const ov=scrapOverrides||{};
    const iN=new Map(navItems.map(i=>[i.material_number,i]));
    const iF=new Map(flrItems.map(i=>[i.material_number,i]));
    const keys=Array.from(new Set([...iN.keys(),...iF.keys()])).sort();
    const rows=[];

    for(const k of keys){
      const a=iN.get(k), b=iF.get(k);           // a = NAV, b = FLOOR
      const src=a||b;
      const r={ key:k,
        description:(a&&a.description)||(b&&b.description)||"",
        nav_desc:a?a.description:"", flr_desc:b?b.description:"",
        nav_part:a?a.part_number:"", flr_part:b?b.part_number:"",
        nav_rev:a?a.drawing_rev:"",  flr_rev:b?b.drawing_rev:"",
        nav_dwg:a?a.drawing_no:"",   flr_dwg:b?b.drawing_no:"",
        nav_fam:a?a.drawing_family:"", flr_fam:b?b.drawing_family:"",
        nav_qty:a?a.qty:null,        flr_qty:b?b.qty:null,
        nav_uom:a?a.quantity_uom:"", flr_uom:b?b.quantity_uom:"",
        nav_lines:a?(a.lines||1):0, nav_parts:a?(a.parts||[]):[],
        nav_lines:a?a.lines:0, replenishment:src.replenishment||"",
        scrap_pct:null, scrap_std:null, scrap_source:"", scrap_observed:false, nav_proposed:null,
        implied_scrap:null, scrap_gap:null,
        variance:null, flags:[], pair:"" };

      // ---- scrap: measured from the floor first, then proposed back to NAV ----
      // NAV carries none, so the observed rate is derived from actual consumption.
      if(r.nav_qty!==null&&r.nav_qty!==0&&r.flr_qty!==null)
        r.implied_scrap=(r.flr_qty/r.nav_qty-1)*100;
      const ovVal = toFloat(ov[k]);
      const colVal = b?b.scrap_pct:null;         // a scrap column on the production BoM
      r.scrap_nav = (a&&a.scrap_pct!==null&&a.scrap_pct!==undefined)?a.scrap_pct:0;  // NAV normally carries none
      r.scrap_std = colVal!==null?colVal:sc.default_pct;   // the production standard, for reference
      if(ovVal!==null){ r.scrap_pct=ovVal; r.scrap_source="set"; }
      else if(colVal!==null){ r.scrap_pct=colVal; r.scrap_source="bom"; }
      else if(r.implied_scrap!==null&&r.implied_scrap>0
              &&r.implied_scrap<=sc.plausible_ceiling_pct){
        r.scrap_pct=round2(r.implied_scrap); r.scrap_source="measured"; }
      else { r.scrap_pct=sc.default_pct; r.scrap_source="default"; }
      if(r.nav_qty!==null&&r.flr_qty!==null) r.nav_proposed=r.nav_qty*(1+r.scrap_pct/100);
      // is the observed rate in line with the production standard?
      // the gap is against the factor in force (master or set here), not the standard rate
      if(r.implied_scrap!==null) r.scrap_gap=r.implied_scrap-r.scrap_pct;

      if(a&&!b) r.flags.push("MISSING_ON_FLOOR");
      else if(b&&!a) r.flags.push("MISSING_IN_NAV");
      else {
        // ---- utilization ----
        // The comparison is NAV vs floor. If both carry the same unit string there is
        // nothing to disagree about, so the raw figures are compared directly even when
        // the unit is not in the conversion table (or is blank). Only a genuine
        // difference in units is a finding.
        const sameUnit = low(a.quantity_uom)===low(b.quantity_uom);
        let navBase=a.qty_base, flrBase=b.qty_base;
        if(sameUnit){ navBase=a.qty; flrBase=b.qty; }
        if(a.uom_conflict||b.uom_conflict) r.flags.push("UOM_CONFLICT");
        if(!sameUnit&&(a.dim==="UNKNOWN"||b.dim==="UNKNOWN")) r.flags.push("UOM_UNKNOWN");
        else if(!sameUnit&&a.dim!==b.dim) r.flags.push("UOM_MISMATCH");
        else if(b.qty===null){
          // Nothing entered = the auditor found nothing to change, so the line is
          // taken as consuming the NAV quantity. Never a finding.
          r.scrap_observed=false; r.implied_scrap=null; r.scrap_gap=null;
        } else {
          // NAV carries no scrap, so the honest comparison is actual vs NAV NET.
          // The scrap rate is what that difference IMPLIES, and is proposed back to NAV.
          r.variance=signedDiff(navBase,flrBase);
          const rd=relDiff(navBase,flrBase);
          const vsStd=relDiff(a.qty_base*(1+r.scrap_std/100),b.qty_base);
          const explainedByScrap = r.implied_scrap!==null
            && r.implied_scrap>0 && r.implied_scrap<=sc.plausible_ceiling_pct;
          if(rd===null||rd<=tol.exact_rel){ /* consumption equals NAV exactly */ }
          else if(explainedByScrap){ /* the gap is scrap - reported as SCRAP_NOT_IN_NAV below */ }
          else if(vsStd!==null&&vsStd<=tol.warning_rel) r.flags.push("DOSAGE_WARNING");
          else r.flags.push("DOSAGE_MISMATCH");
          // A recorded figure is an observation even when it equals NAV: it confirms
          // that nothing is being scrapped on that item.
          r.scrap_observed = true;
          // Scrap findings apply only where the excess is plausibly scrap. Beyond the
          // ceiling it is a utilization error, and proposing it as a scrap factor would be absurd.
          if(explainedByScrap){
            if(r.implied_scrap>=sc.gap_threshold_pp) r.flags.push("SCRAP_NOT_IN_NAV");
            if(r.scrap_gap!==null&&r.scrap_gap>=sc.gap_threshold_pp) r.flags.push("SCRAP_UNDERSTATED");
            else if(r.scrap_gap!==null&&r.scrap_gap<=-sc.gap_threshold_pp) r.flags.push("SCRAP_OVERSTATED");
          }
        }
        // ---- identity: part number / material / revision ----
        // a blank entry on the floor side means "as per NAV" - never a finding
        if(ck.part_number&&r.nav_part&&r.flr_part&&low(r.nav_part)!==low(r.flr_part))
          r.flags.push("PARTNO_MISMATCH");
        if(ck.description&&r.nav_desc&&r.flr_desc&&low(r.nav_desc)!==low(r.flr_desc))
          r.flags.push("MATERIAL_DIFFERS");
        if(ck.drawing_rev){
          // Drawings are presumed correct. A finding is raised only where the auditor
          // has actually entered a different part/drawing number or revision — a blank
          // or identical entry means the line is building to the approved drawing.
          const aD=r.nav_dwg, fD=r.flr_dwg, aR=r.nav_rev, fR=r.flr_rev;
          r.drawing_amended = !!(fD&&aD&&low(fD)!==low(aD)) || !!(fR&&aR&&low(fR)!==low(aR));
          if(fD&&aD&&low(fD)!==low(aD)){
            // same family, different trailing letter = superseded revision;
            // a different family = a different part/drawing altogether
            if(r.nav_fam&&r.flr_fam&&low(r.nav_fam)===low(r.flr_fam)) r.flags.push("REV_MISMATCH");
            else r.flags.push("DRAWING_NO_MISMATCH");
          } else if(fR&&aR&&low(fR)!==low(aR)) r.flags.push("REV_MISMATCH");
        }
      }
      // did the auditor actually amend anything on this line?
      r.amended = !!(a&&b) && (
        (b.qty!==null&&a.qty!==null&&relDiff(a.qty,b.qty)>1e-9) ||
        (!!r.flr_part&&!!r.nav_part&&low(r.flr_part)!==low(r.nav_part)) ||
        (!!r.flr_desc&&!!r.nav_desc&&low(r.flr_desc)!==low(r.nav_desc)) ||
        !!r.drawing_amended );
      if(!r.flags.length) r.flags.push("MATCH");
      rows.push(r);
    }

    // ---- substitution: a NAV-only item and a floor-only item that are the same thing ----
    if(cfg.checks.detect_substitution){
      const navOnly=rows.filter(r=>r.flags.includes("MISSING_ON_FLOOR"));
      const flrOnly=rows.filter(r=>r.flags.includes("MISSING_IN_NAV"));
      for(const n of navOnly){
        const m=flrOnly.find(f=>!f.pair&&(
          (n.nav_part&&f.flr_part&&low(n.nav_part)===low(f.flr_part)) ||
          (n.nav_desc&&f.flr_desc&&low(n.nav_desc)===low(f.flr_desc)) ||
          (n.nav_dwg&&f.flr_dwg&&low(n.nav_dwg)===low(f.flr_dwg))));
        if(m){
          n.flags=["SUBSTITUTION"]; n.pair=m.key;
          m.flags=["SUBSTITUTION"]; m.pair=n.key;
        }
      }
    }

    for(const r of rows){
      r.status = r.flags.some(f=>HARD.includes(f)) ? "FAIL"
               : (r.flags[0]==="MATCH" ? "MATCH"
               : (r.flags.every(f=>CAPTURE_FLAGS.includes(f)) ? "PENDING" : "WARN"));
    }
    return rows;
  }

  /* ---------------- health ---------------- */
  function computeHealth(rows,cfg){
    const h=cfg.health;
    if(!rows.length) return { score:null, grade:"—", coverage:null, dosage:null, identity:null,
      drawing:null, pending:0, judged:0, findings:0, amended:0, dwgPool:0, dwgHard:0, dwgGaps:0, dwgAmended:0, scrapGaps:0,
      total:0, match:0, warn:0, fail:0, missNav:0, missFlr:0, subs:0, common:0 };
    const total=rows.length;
    const missFlr=rows.filter(r=>r.flags.includes("MISSING_ON_FLOOR")).length;
    const missNav=rows.filter(r=>r.flags.includes("MISSING_IN_NAV")).length;
    const subs=rows.filter(r=>r.flags.includes("SUBSTITUTION")).length;
    const coverage=1-(missFlr+missNav+subs)/total;

    const common=rows.filter(r=>r.nav_qty!==null&&r.flr_qty!==null);
    // the quantity story includes scrap: material consumed but unplanned is a defect
    const dosBad=common.filter(r=>r.flags.includes("DOSAGE_MISMATCH")||
      r.flags.includes("UOM_MISMATCH")||r.flags.includes("UOM_UNKNOWN")||r.flags.includes("UOM_CONFLICT")||
      r.flags.includes("SCRAP_NOT_IN_NAV")||r.flags.includes("SCRAP_UNDERSTATED")||
      r.flags.includes("SCRAP_OVERSTATED")).length;
    const dosage=common.length?1-dosBad/common.length:null;

    const idPool=rows.filter(r=>!r.flags.includes("MISSING_ON_FLOOR")&&!r.flags.includes("MISSING_IN_NAV"));
    const idBad=idPool.filter(r=>r.flags.includes("PARTNO_MISMATCH")||
      r.flags.includes("MATERIAL_DIFFERS")).length;
    const identity=idPool.length?1-idBad/idPool.length:null;
    // drawings: only items that actually reference a drawing on either side
    const dwgPool=rows.filter(r=>r.nav_dwg||r.flr_dwg||r.nav_rev||r.flr_rev);
    const dwgHard=dwgPool.filter(r=>r.flags.includes("DRAWING_NO_MISMATCH")||r.flags.includes("REV_MISMATCH")).length;
    const dwgAmended=dwgPool.filter(r=>r.drawing_amended).length;
    const dwgGaps=0;   // nothing is outstanding: an unamended drawing is taken as correct
    const drawing=dwgPool.length?1-dwgHard/dwgPool.length:null;
    const scrapGaps=rows.filter(r=>r.flags.includes("SCRAP_UNDERSTATED")||r.flags.includes("SCRAP_OVERSTATED")).length;

    let num=0,den=0;
    num+=h.w_coverage*coverage; den+=h.w_coverage;
    if(dosage!==null){ num+=h.w_dosage*dosage; den+=h.w_dosage; }
    if(identity!==null){ num+=h.w_identity*identity; den+=h.w_identity; }
    if(drawing!==null){ num+=(h.w_drawing||0)*drawing; den+=(h.w_drawing||0); }
    const pending=rows.filter(r=>r.status==="PENDING").length;
    const amended=rows.filter(r=>r.amended).length;
    const judged=rows.filter(r=>r.status!=="PENDING").length;
    const findings=rows.filter(r=>r.status==="FAIL"||r.status==="WARN").length;
    // With nothing measured and nothing else wrong there is nothing to score yet.
    const scorable = rows.length>0;   // unamended lines are conforming, so always scorable
    const score=(den&&scorable)?Math.round(100*num/den):null;
    let grade="—"; const b=h.grade_bands;
    if(score!==null){ grade="E"; for(const g of ["A","B","C","D"]) if(score>=b[g]){ grade=g; break; } }
    return { score, grade, coverage, dosage, identity, drawing, pending, judged, findings, amended,
      dwgPool:dwgPool.length, dwgHard, dwgGaps, dwgAmended, scrapGaps, total,
      match:rows.filter(r=>r.status==="MATCH").length,
      warn:rows.filter(r=>r.status==="WARN").length,
      fail:rows.filter(r=>r.status==="FAIL").length,
      missNav, missFlr, subs, common:common.length };
  }

  /* ---------------- corrective actions ---------------- */
  const F=(x,u)=>x===null||x===undefined?"—":fmtNum(x)+(u?" "+u:"");
  function buildActions(rows,cfg){
    const acts=[];
    const add=o=>acts.push(o);
    for(const r of rows){
      if(r.flags.includes("MISSING_IN_NAV"))
        add({ item:r.key, description:r.flr_desc||r.description, area:"Missing item", priority:"Critical",
          issue:"Consumed on the production floor but absent from the NAV BoM",
          evidence:`Floor utilization ${F(r.flr_qty,r.flr_uom)}; no NAV line`,
          action:`Add ${r.key} to the NAV BoM at a verified utilization (floor shows ${F(r.flr_qty,r.flr_uom)}) — consumption is currently untracked and uncosted`,
          target:"NAV BoM" });
      else if(r.flags.includes("MISSING_ON_FLOOR"))
        add({ item:r.key, description:r.nav_desc||r.description, area:"Missing item", priority:"High",
          issue:"On the NAV BoM but not present on the production floor",
          evidence:`NAV utilization ${F(r.nav_qty,r.nav_uom)}; not recorded on the floor`,
          action:`Confirm whether ${r.key} is still consumed. If it is, correct the floor record; if not, remove it from the NAV BoM via ECN`,
          target:"NAV BoM / Floor record" });
      else if(r.flags.includes("SUBSTITUTION")&&r.nav_qty!==null)
        add({ item:r.key, description:r.description, area:"Substitution", priority:"Critical",
          issue:`Material substituted on the line — floor uses ${r.pair} in place of ${r.key}`,
          evidence:`NAV ${r.key} ${F(r.nav_qty,r.nav_uom)} \u2194 floor ${r.pair}`,
          action:`Confirm ${r.pair} is an approved alternate for ${r.key}. If approved, update the NAV BoM; if not, raise a nonconformance and revert the line`,
          target:"NAV BoM / Quality" });
      if(r.flags.includes("SCRAP_NOT_IN_NAV"))
        add({ item:r.key, description:r.description, area:"Scrap factor", priority:"High",
          issue:`Production consumes ${round2(r.implied_scrap)}% scrap that the NAV BoM does not allow for`,
          evidence:`NAV net ${F(r.nav_qty,r.nav_uom)} carries no scrap; the floor consumed ${F(r.flr_qty,r.flr_uom)}`,
          action:`Add a ${round2(r.scrap_pct)}% scrap factor for ${r.key} to the NAV BoM (quantity becomes ${F(r.nav_proposed,r.nav_uom)}) so planning, issuing and costing cover the ${F(r.flr_qty,r.flr_uom)} actually consumed`,
          target:"NAV BoM (scrap %)" });
      if(r.flags.includes("SCRAP_UNDERSTATED"))
        add({ item:r.key, description:r.description, area:"Scrap factor", priority:"High",
          issue:`Consumption exceeds the allowed scrap — actual implies ${round2(r.implied_scrap)}% against the ${round2(r.scrap_std)}% production allowance`,
          evidence:`Production standard ${round2(r.scrap_std)}% would give ${F(r.nav_proposed,r.nav_uom)}; the floor actually consumed ${F(r.flr_qty,r.flr_uom)} against NAV net ${F(r.nav_qty,r.nav_uom)}`,
          action:`Investigate process loss on ${r.key}. If ${round2(r.implied_scrap)}% is the true rate, revise the production BoM scrap factor and add it to NAV`,
          target:"Production BoM (scrap %) / Process" });
      if(r.flags.includes("SCRAP_OVERSTATED"))
        add({ item:r.key, description:r.description, area:"Scrap factor", priority:"Medium",
          issue:`Consumption is below the allowed scrap — the production BoM allows ${round2(r.scrap_pct)}% but actual implies ${round2(r.implied_scrap)}%`,
          evidence:`Production standard ${round2(r.scrap_std)}% would give ${F(r.nav_proposed,r.nav_uom)}; the floor actually consumed only ${F(r.flr_qty,r.flr_uom)}`,
          action:`Reduce the production BoM scrap factor for ${r.key} to about ${round2(r.implied_scrap)}% to stop over-issuing material`,
          target:"Production BoM (scrap %)" });
      if(r.flags.includes("DOSAGE_MISMATCH"))
        add({ item:r.key, description:r.description, area:"Utilization", priority:"High",
          issue:`Floor utilization differs from NAV by ${pctStr(r.variance)}`,
          evidence:`NAV ${F(r.nav_qty,r.nav_uom)} vs floor ${F(r.flr_qty,r.flr_uom)}`,
          action:`Investigate ${r.key}: correct the process to the BoM utilization, or update the NAV BoM to the true consumption of ${F(r.flr_qty,r.flr_uom)}`,
          target:"NAV BoM / Process" });
      else if(r.flags.includes("DOSAGE_WARNING"))
        add({ item:r.key, description:r.description, area:"Utilization", priority:"Low",
          issue:`Floor utilization differs slightly (${pctStr(r.variance)})`,
          evidence:`NAV ${F(r.nav_qty,r.nav_uom)} vs floor ${F(r.flr_qty,r.flr_uom)}`,
          action:`Confirm this is measurement rounding on ${r.key}; no BoM change if within process capability`,
          target:"Review" });
      if(r.flags.includes("UOM_MISMATCH")||r.flags.includes("UOM_UNKNOWN")||r.flags.includes("UOM_CONFLICT"))
        add({ item:r.key, description:r.description, area:"Unit of measure", priority:"High",
          issue:"Units of measure are not comparable, so the utilization cannot be verified",
          evidence:`NAV ${r.nav_uom||"?"} vs floor ${r.flr_uom||"?"}`,
          action:`Align the unit of measure for ${r.key} on both records, then re-check the utilization`,
          target:"NAV BoM / Floor record" });
      if(r.flags.includes("PARTNO_MISMATCH"))
        add({ item:r.key, description:r.description, area:"Part number", priority:"High",
          issue:"Part number on the floor disagrees with NAV",
          evidence:`NAV ${r.nav_part||"—"} vs floor ${r.flr_part||"—"}`,
          action:`Verify which part number is correct for ${r.key} and correct the other record; check no wrong part has been issued`,
          target:"NAV BoM / Drawing register" });
      if(r.flags.includes("MATERIAL_DIFFERS"))
        add({ item:r.key, description:r.description, area:"Material", priority:"High",
          issue:"Same item number but a different material description on the floor",
          evidence:`NAV "${r.nav_desc}" vs floor "${r.flr_desc}"`,
          action:`Confirm the physical material for ${r.key} — a differing description under one item number suggests the wrong material is being consumed`,
          target:"Quality / NAV BoM" });
      if(r.flags.includes("DRAWING_NO_MISMATCH"))
        add({ item:r.key, description:r.description, area:"Drawing", priority:"Critical",
          issue:"The line is building to a different part/drawing than the approved one",
          evidence:`Approved ${r.nav_dwg||"—"} vs in use ${r.flr_dwg||"—"} (different drawing family)`,
          action:`Stop work on ${r.key} until the controlling drawing is confirmed; withdraw the uncontrolled drawing from the line`,
          target:"Drawing register / Quality" });
      if(r.flags.includes("REV_NOT_CAPTURED"))
        add({ item:r.key, description:r.description, area:"Drawing", priority:"Low",
          issue:"The approved record states a revision but none was captured from the floor",
          evidence:`Approved rev ${r.nav_rev}; nothing captured on the floor`,
          action:`Record the drawing revision in use for ${r.key} at the next line check`, target:"Audit" });
      if(r.flags.includes("DRAWING_NOT_CAPTURED"))
        add({ item:r.key, description:r.description, area:"Drawing", priority:"Low",
          issue:"No drawing reference captured from the floor",
          evidence:`Approved drawing ${r.nav_dwg}; nothing captured on the floor`,
          action:`Record which drawing is in use for ${r.key} at the next line check`, target:"Audit" });
      if(r.flags.includes("REV_MISMATCH"))
        add({ item:r.key, description:r.description, area:"Drawing", priority:"High",
          issue:"The line is working to a superseded or unapproved revision",
          evidence:`Approved ${r.nav_dwg||"—"} (rev ${r.nav_rev||"—"}) vs in use ${r.flr_dwg||"—"} (rev ${r.flr_rev||"—"})`,
          action:`Withdraw the superseded drawing from the line and confirm the controlled revision for ${r.key}`,
          target:"Drawing register" });
    }
    const rank={Critical:0,High:1,Medium:2,Low:3};
    acts.sort((x,y)=>rank[x.priority]-rank[y.priority]);
    acts.forEach((a,i)=>a.ref="A"+String(i+1).padStart(3,"0"));
    return acts;
  }


  /* ================= EDITABLE BoM CHANGE LIST =================
     Each compared line carries a disposition: what to do to the NAV BoM.
     The tool suggests one from the findings; the user can override any line,
     including lines that currently agree (e.g. an item nobody actually uses). */
  const DISPOSITIONS = [
    { id:"NONE",        label:"No change",                group:"none"        },
    { id:"ADD",         label:"Add to BoM",               group:"add"         },
    { id:"REMOVE",      label:"Remove from BoM",          group:"remove"      },
    { id:"DOSAGE",      label:"Amend utilization",             group:"amend"       },
    { id:"SCRAP",       label:"Amend scrap factor",       group:"amend"       },
    { id:"PARTNO",      label:"Amend part number",        group:"amend"       },
    { id:"REV",         label:"Amend drawing revision",   group:"amend"       },
    { id:"DRAWING",     label:"Amend drawing reference",  group:"amend"       },
    { id:"MATERIAL",    label:"Amend material / description", group:"amend"   },
    { id:"INVESTIGATE", label:"Investigate first",        group:"investigate" },
  ];
  const DISP_GROUP = {}; DISPOSITIONS.forEach(d=>DISP_GROUP[d.id]=d.group);
  const DISP_LABEL = {}; DISPOSITIONS.forEach(d=>DISP_LABEL[d.id]=d.label);

  /* What the findings imply. Returns {action, target, reason}. */
  function suggestDisposition(r){
    const f=x=>r.flags.includes(x);
    if(f("MISSING_IN_NAV"))
      return { action:"ADD", target:r.flr_qty, reason:"Consumed on the floor but not on the NAV BoM" };
    if(f("MISSING_ON_FLOOR"))
      return { action:"REMOVE", target:"", reason:"On the NAV BoM but not found on the floor" };
    if(f("SUBSTITUTION"))
      return { action:"INVESTIGATE", target:"", reason:"Material substituted on the line — needs an approval decision" };
    if(f("UOM_MISMATCH")||f("UOM_UNKNOWN")||f("UOM_CONFLICT"))
      return { action:"INVESTIGATE", target:"", reason:"Units of measure are not comparable" };
    if(f("SCRAP_NOT_IN_NAV")&&!f("SCRAP_UNDERSTATED")&&!f("SCRAP_OVERSTATED"))
      return { action:"SCRAP", target:round2(r.implied_scrap),
        reason:`Floor audit shows ${round2(r.implied_scrap)}% scrap on this item; NAV holds no scrap factor, so add one` };
    if(f("SCRAP_UNDERSTATED"))
      return { action:"SCRAP", target:round2(r.implied_scrap),
        reason:`Floor audit implies ${round2(r.implied_scrap)}% scrap, above the ${round2(r.scrap_pct)}% factor proposed for this item` };
    if(f("SCRAP_OVERSTATED"))
      return { action:"SCRAP", target:round2(r.implied_scrap),
        reason:`The proposed factor is ${round2(r.scrap_pct)}% but the floor audit implies only ${round2(r.implied_scrap)}%` };
    if((r.scrap_source==="set"||r.scrap_source==="measured")&&round2(r.scrap_pct)>0)
      return { action:"SCRAP", target:round2(r.scrap_pct),
        reason:`Propose a ${round2(r.scrap_pct)}% scrap allowance in NAV, measured from actual consumption (production standard ${round2(r.scrap_std)}%)` };
    if(f("DOSAGE_MISMATCH"))
      return { action:"DOSAGE", target:r.flr_qty, reason:"Floor consumption differs materially from the NAV utilization, beyond any plausible scrap allowance" };
    if(f("PARTNO_MISMATCH"))
      return { action:"PARTNO", target:r.flr_part, reason:"Part number on the floor disagrees with NAV" };
    if(f("DRAWING_NO_MISMATCH"))
      return { action:"DRAWING", target:r.flr_dwg,
        reason:`Line is building to part/drawing ${r.flr_dwg||"?"} but ${r.nav_dwg||"?"} is the approved one` };
    if(f("REV_MISMATCH"))
      return { action:"REV", target:r.flr_dwg||r.flr_rev,
        reason:`Line is building to ${r.flr_dwg||("rev "+r.flr_rev)} (revision ${r.flr_rev||"?"}) but ${r.nav_dwg||("rev "+r.nav_rev)} (revision ${r.nav_rev||"?"}) is approved` };
    if(f("MATERIAL_DIFFERS"))
      return { action:"INVESTIGATE", target:"", reason:"Different material description under the same item number" };
    if(f("DOSAGE_WARNING"))
      return { action:"NONE", target:"", reason:"Difference is within measurement rounding" };
    return { action:"NONE", target:"", reason:"" };
  }

  /* Reason text when the auditor overrides rather than accepting a suggestion. */
  const OVERRIDE_REASON = {
    ADD:         "Confirmed on the line as used but missing from the BoM",
    REMOVE:      "Confirmed on the line as not used",
    DOSAGE:      "Utilization corrected against actual consumption",
    SCRAP:       "Production scrap factor revised against actual consumption",
    PARTNO:      "Part number corrected against the part in use",
    REV:         "Revision corrected against the drawing in use",
    DRAWING:     "Drawing reference corrected against the drawing in use",
    MATERIAL:    "Material description corrected against the material in use",
    INVESTIGATE: "Raised for investigation",
    NONE:        "",
  };

  /* Effective disposition = user override if present, else the suggestion. */
  function effectiveDisposition(r,overrides){
    const sug=suggestDisposition(r);
    const ov=overrides&&overrides[r.key];
    if(!ov||!ov.touched) return { action:sug.action, target:sug.target, note:(ov&&ov.note)||"",
      reason:sug.reason, suggested:true, suggestion:sug.action };
    const reason = ov.reason
      || ((ov.action===sug.action && sug.reason) ? sug.reason : (OVERRIDE_REASON[ov.action]||""));
    return { action:ov.action, target:ov.target!==undefined&&ov.target!==""?ov.target:sug.target,
      note:ov.note||"", reason, suggested:false, suggestion:sug.action };
  }

  /* The change list actioned against NAV. */
  function buildChangeList(rows,overrides,manualAdds,meta){
    const out=[];
    for(const r of rows){
      const d=effectiveDisposition(r,overrides);
      if(d.action==="NONE") continue;
      out.push({
        change:d.action, group:DISP_GROUP[d.action], label:DISP_LABEL[d.action],
        item:r.key, description:r.description||r.nav_desc||r.flr_desc,
        part_current:r.nav_part, part_new:(d.action==="PARTNO")?d.target:"",
        dosage_current:r.nav_qty, dosage_new:(d.action==="ADD"||d.action==="DOSAGE")?d.target:"",
        scrap_current:(r.scrap_nav===undefined?0:r.scrap_nav),
        scrap_new:(d.action==="SCRAP")?d.target:"",
        dwg_current:r.nav_dwg, dwg_new:(d.action==="DRAWING")?d.target:"",
        gross_current:r.nav_proposed, implied_scrap:r.implied_scrap,
        uom:r.nav_uom||r.flr_uom, rev_current:r.nav_rev,
        rev_new:(d.action==="REV")?d.target:"",
        reason:d.reason, note:d.note, source:"comparison",
        suggested:d.suggested, override:!d.suggested&&d.action!==d.suggestion,
      });
    }
    (manualAdds||[]).forEach(m=>{
      const blank=!text(m.mat)&&!text(m.desc);
      out.push({ blank, change:m.action||"ADD", group:DISP_GROUP[m.action||"ADD"], label:DISP_LABEL[m.action||"ADD"],
        item:text(m.mat), description:text(m.desc), part_current:"", part_new:text(m.part),
        dosage_current:null, dosage_new:text(m.qty), scrap_current:null, scrap_new:text(m.scrap),
        gross_current:null, implied_scrap:null,
        uom:text(m.uom), rev_current:"", rev_new:text(m.rev),
        reason:text(m.reason)||"Raised manually", note:text(m.note), source:"manual",
        mid:m.__id, suggested:false, override:false });
    });
    const order={add:0,remove:1,amend:2,investigate:3};
    out.sort((a,b)=>(order[a.group]-order[b.group])||String(a.item).localeCompare(String(b.item)));
    return out;
  }

  function changeListCSV(list,meta){
    const rows=[["NAV BoM change list"]];
    (meta||[]).forEach(m=>rows.push([m[0],m[1]]));
    rows.push([],["Change","Item No","Description","Current utilization","New utilization","UoM",
      "Current scrap %","New scrap %","Implied scrap %",
      "Current part no","New part no","Current rev","New rev","Reason","Note","Origin"]);
    list.filter(c=>!c.blank).forEach(c=>rows.push([c.label,c.item,c.description,
      c.dosage_current===null?"":fmtNum(c.dosage_current),
      c.dosage_new===""||c.dosage_new===null?"":fmtNum(c.dosage_new),
      c.uom,
      c.scrap_current===null||c.scrap_current===undefined?"":fmtNum(c.scrap_current),
      c.scrap_new===""||c.scrap_new===null||c.scrap_new===undefined?"":fmtNum(c.scrap_new),
      c.implied_scrap===null||c.implied_scrap===undefined?"":fmtNum(Math.round(c.implied_scrap*100)/100),
      c.part_current,c.part_new,c.rev_current,c.rev_new,c.reason,c.note,
      c.source==="manual"?"raised manually":(c.suggested?"suggested by comparison":"decided by auditor")]));
    return toCSV(rows);
  }

  /* ---------------- narrative summary ---------------- */
  function buildSummary(rows,health,actions){
    const s=[]; if(!rows.length) return s;
    const c=f=>rows.filter(r=>r.flags.includes(f)).length;
    const mn=c("MISSING_IN_NAV"), mf=c("MISSING_ON_FLOOR"), su=c("SUBSTITUTION")/2;
    const dm=c("DOSAGE_MISMATCH"), dw=c("DOSAGE_WARNING");
    const pm=c("PARTNO_MISMATCH"), md=c("MATERIAL_DIFFERS"), rm=c("REV_MISMATCH");
    const um=c("UOM_MISMATCH")+c("UOM_UNKNOWN")+c("UOM_CONFLICT");
    s.push(`${health.total} item${health.total===1?"":"s"} on the NAV BoM \u00b7 ${health.amended} amended by the auditor \u00b7 ${health.findings} finding${health.findings===1?"":"s"}. Lines the auditor did not change are taken as matching NAV.`);
    if(mn) s.push(`${mn} material${mn>1?"s are":" is"} consumed on the floor but ${mn>1?"are":"is"} not on the NAV BoM at all — untracked and uncosted consumption, and the highest-priority gap.`);
    if(mf) s.push(`${mf} item${mf>1?"s appear":" appears"} on the NAV BoM but ${mf>1?"were":"was"} not found on the floor — either obsolete on the BoM or missed during the audit.`);
    if(su) s.push(`${su} apparent substitution${su>1?"s":""} detected, where the floor uses a different item number for what looks like the same material.`);
    const sn_=c("SCRAP_NOT_IN_NAV"), su_=c("SCRAP_UNDERSTATED"), so_=c("SCRAP_OVERSTATED");
    if(sn_) s.push(`${sn_} item${sn_>1?"s show":" shows"} process scrap on the floor while NAV holds no scrap factor at all — that material is never planned, issued or costed, so NAV under-states requirements. A factor is proposed for each on the Scrap factors tab.`);
    if(su_) s.push(`${su_} item${su_>1?"s run":" runs"} above the scrap factor proposed for ${su_>1?"them":"it"} — investigate process loss before settling the figure that goes into NAV.`);
    if(so_) s.push(`${so_} item${so_>1?"s run":" runs"} below the proposed factor, so proposing it unchanged would over-issue material.`);
    if(dm) s.push(`${dm} utilization${dm>1?"s differ":" differs"} materially between NAV and actual floor consumption — this drives wrong costing and wrong material planning.`);
    if(dw) s.push(`${dw} utilization${dw>1?"s differ":" differs"} only slightly, consistent with measurement rounding.`);
    if(um) s.push(`${um} line${um>1?"s have":" has"} incomparable units of measure, so ${um>1?"those utilizations":"that utilization"} cannot be verified.`);
    if(pm) s.push(`${pm} part number${pm>1?"s disagree":" disagrees"} between the floor and NAV.`);
    if(md) s.push(`${md} item${md>1?"s carry":" carries"} a different material description on the floor under the same item number — a wrong-material risk.`);
    const dnm=c("DRAWING_NO_MISMATCH");
    if(dnm) s.push(`${dnm} item${dnm>1?"s are":" is"} being built to a different drawing than the approved one — the highest drawing-control risk here.`);
    if(rm) s.push(`${rm} drawing revision${rm>1?"s in use on the floor differ":" in use on the floor differs"} from the approved revision.`);

    if(actions.length){
      const cr=actions.filter(a=>a.priority==="Critical").length, hi=actions.filter(a=>a.priority==="High").length;
      s.push(`${actions.length} corrective action${actions.length>1?"s":""}${cr?`, ${cr} critical`:""}${hi?`, ${hi} high priority`:""}.`);
    } else s.push("No corrective action required — the floor record matches the NAV BoM within tolerance.");
    return s;
  }

  /* ================= FAMILY: products sharing a model code ================= */
  // KE_WB3.2 RW-AVSI and KE_WB3.2 LIKANO-RW are both WB3.2
  function familyKey(name){
    const s=text(name).toUpperCase().replace(/^KE[\s_\-]*/,"").trim();
    // A model code is 2-4 letters at a word boundary followed by a number.
    // The boundary matters: without it "PRODUCT 1" matched as "DUCT1".
    let m=/\b([A-Z]{2,4})\s?-?(\d+\.\d+)/.exec(s);         // prefer WB3.2, CA5.2, AD1.0
    if(!m) m=/\b([A-Z]{2,4})\s?-?(\d+)\b/.exec(s);          // then WB3, CA5
    if(!m) return "";
    if(/^(THE|AND|FOR|WITH|PCS|KGS|SET|NEW|OLD|REV)$/.test(m[1])) return "";
    return m[1]+m[2];
  }
  // 11076B and 11076C, or 1A and 1.1, are the same part at different issues.
  // Strip a trailing letter and a trailing .N so they land on one key.
  function familyPairKey(item){
    let s=low(item).replace(/[\s_\-]+/g,"");
    s=s.replace(/\.\d+$/,"");        // 1.1 -> 1
    s=s.replace(/[a-z]+$/,"");        // 11076b -> 11076
    return s;
  }
  // Two different part numbers can be the same material in another form:
  // 12013 "SS304; Wire Coil; 3mm dia"  vs  10098 "SS304; Wire; 3mm dia x 2400mm L".
  // Compare the significant words rather than the numbers.
  const DESC_STOP=new Set(["the","and","with","without","for","of","in","on","to","a","an",
    "x","by","per","type","grade","new","old","std","standard","assy","assembly","pcs","pc"]);
  function descTokens(d){
    return [...new Set(low(d).split(/[^a-z0-9.]+/)
      .map(t=>t.replace(/\.$/,""))
      .filter(t=>t.length>1&&!DESC_STOP.has(t)))];
  }
  // overlap coefficient, with a floor on how many words must actually agree
  function descSimilar(a,b){
    const A=descTokens(a), B=descTokens(b);
    if(A.length<2||B.length<2) return 0;
    const set=new Set(B);
    const hit=A.filter(t=>set.has(t));
    if(hit.length<2) return 0;
    return hit.length/Math.min(A.length,B.length);
  }
  function isVariantItem(desc,cfg){
    const w=(cfg&&cfg.family&&cfg.family.variant_words)||DEFAULTS.family.variant_words;
    const d=low(desc);
    return w.some(x=>d.includes(x));
  }
  // products: [{name, sku, family, items:[prepared items]}]
  function familyCompare(products,cfg){
    const tol=((cfg&&cfg.family)||DEFAULTS.family).util_tolerance_rel;
    const fams=new Map();
    products.forEach(p=>{
      const k=text(p.family)||familyKey(p.sku)||familyKey(p.name);
      if(!k) return;
      if(!fams.has(k)) fams.set(k,{family:k,members:[]});
      fams.get(k).members.push(p);
    });
    const out=[];
    fams.forEach(f=>{
      if(f.members.length<2) return;                    // nothing to compare against
      const names=f.members.map(m=>m.name);
      const idx=f.members.map(m=>{
        const g=new Map(); (m.items||[]).forEach(i=>g.set(low(i.material_number),i)); return g; });
      const keys=[];
      const seen=new Set();
      f.members.forEach(m=>(m.items||[]).forEach(i=>{
        const k=low(i.material_number); if(k&&!seen.has(k)){ seen.add(k); keys.push(i.material_number); } }));
      const rows=keys.map(key=>{
        const k=low(key);
        const cells=idx.map(g=>{ const i=g.get(k); return i?{qty:i.qty,uom:i.quantity_uom,desc:i.description}:null; });
        const present=cells.filter(Boolean);
        const desc=(present[0]&&present[0].desc)||"";
        const variant=isVariantItem(desc,cfg);
        const missing=cells.map((c,i)=>c?null:names[i]).filter(Boolean);
        const qtys=present.map(c=>toFloat(c.qty)).filter(v=>v!==null);
        const mn=qtys.length?Math.min(...qtys):null, mx=qtys.length?Math.max(...qtys):null;
        const spread=(mn!==null&&mn!==0)?(mx-mn)/mn:null;
        let flag="MATCH";
        if(missing.length) flag=variant?"VARIANT_MISSING":"FAMILY_MISSING";
        else if(spread!==null&&spread>tol) flag=variant?"VARIANT_UTIL":"FAMILY_UTIL_DIFF";
        const uoms=[...new Set(present.map(c=>text(c.uom)).filter(Boolean))];
        return { key, desc, variant, cells, missing, min:mn, max:mx, spread, flag,
          uom:uoms.join("/"), uomClash:uoms.length>1 };
      });
      // ---- pair up "same part, different number" before counting ----
      const orphan=rows.filter(r=>r.flag==="FAMILY_MISSING"||r.flag==="VARIANT_MISSING");
      const used=new Set();
      const merged=[];
      orphan.forEach(A=>{
        if(used.has(A.key)) return;
        const ak=familyPairKey(A.key), ad=low(A.desc);
        // candidates that fill each other's gaps, ranked by how strongly they match
        const cands=orphan.filter(x=>x!==A&&!used.has(x.key)
          && A.cells.some((c,i)=>c&&!x.cells[i]) && x.cells.some((c,i)=>c&&!A.cells[i]))
          .map(x=>{
            let score=0, basis="";
            if(ak&&ak===familyPairKey(x.key)){ score=1.0; basis="same part-number base "+ak; }
            else if(ad&&ad===low(x.desc)){ score=0.98; basis="identical description"; }
            else { const s=descSimilar(A.desc,x.desc);
              if(s>=0.6){ score=s; basis="same material described differently"; } }
            return { row:x, score, basis };
          }).filter(x=>x.score>0)
          .sort((p,q)=>q.score-p.score);
        if(!cands.length) return;
        const B=cands[0].row, basis=cands[0].basis;
        used.add(A.key); used.add(B.key);
        const parts=names.map((n,i)=>A.cells[i]?A.key:(B.cells[i]?B.key:""));
        const cells=names.map((n,i)=>A.cells[i]||B.cells[i]||null);
        const qtys=cells.filter(Boolean).map(c=>toFloat(c.qty)).filter(v=>v!==null);
        const mn=qtys.length?Math.min(...qtys):null, mx=qtys.length?Math.max(...qtys):null;
        const variant=A.variant&&B.variant;
        merged.push({ key:A.key+" / "+B.key, keys:[A.key,B.key], parts, desc:A.desc||B.desc,
          variant, cells, missing:[], min:mn, max:mx,
          spread:(mn!==null&&mn!==0)?(mx-mn)/mn:null,
          flag:variant?"VARIANT_PART_DIFF":"FAMILY_PART_DIFF",
          uom:[...new Set(cells.filter(Boolean).map(c=>text(c.uom)).filter(Boolean))].join("/"),
          pairKey:familyPairKey(A.key), basis,
          descs:names.map((n,i)=>A.cells[i]?A.desc:(B.cells[i]?B.desc:"")) });
      });
      const kept=rows.filter(r=>!used.has(r.key));
      rows.length=0; rows.push(...merged,...kept);
      const cnt=f2=>rows.filter(r=>r.flag===f2).length;
      out.push({ family:f.family, names, members:f.members, rows,
        missing:cnt("FAMILY_MISSING"), utilDiff:cnt("FAMILY_UTIL_DIFF"),
        partDiff:cnt("FAMILY_PART_DIFF"),
        variants:cnt("VARIANT_MISSING")+cnt("VARIANT_UTIL")+cnt("VARIANT_PART_DIFF"),
        matched:cnt("MATCH"), total:rows.length,
        findings:cnt("FAMILY_MISSING")+cnt("FAMILY_UTIL_DIFF")+cnt("FAMILY_PART_DIFF") });
    });
    out.sort((a,b)=>b.findings-a.findings);
    return out;
  }

  /* ================= CROSS-PRODUCT COVERAGE =================
     Any 2 to 5 products, related or not. Answers one question: which items are
     carried by every product, and which are carried by some but not all — the
     gaps being where a BoM is most likely wrong. */
  function crossCompare(products,cfg){
    const conf=(cfg&&cfg.family)||DEFAULTS.family;
    const tol=conf.util_tolerance_rel;
    const n=products.length;
    const names=products.map(p=>p.name);
    const idx=products.map(p=>{
      const m=new Map();
      (p.items||[]).forEach(i=>{ const k=low(i.material_number); if(k&&!m.has(k)) m.set(k,i); });
      return m;
    });
    // "item|product" pairs an admin has confirmed are correct as they are
    const okd=new Set(((cfg&&cfg.__accepted)||[]).map(s=>low(s)));
    const cost=new Map();      // item -> unit cost from the material master
    ((cfg&&cfg.__materials)||[]).forEach(x=>{
      const k=low(x.item), v=toFloat(x.unit_cost);
      if(k&&v!==null) cost.set(k,v);
    });
    const keys=[], seen=new Set();
    products.forEach(p=>(p.items||[]).forEach(i=>{
      const k=low(i.material_number);
      if(k&&!seen.has(k)){ seen.add(k); keys.push(i.material_number); }
    }));
    const rows=keys.map(key=>{
      const k=low(key);
      const cells=idx.map(m=>{ const i=m.get(k); return i?{qty:toFloat(i.qty),uom:text(i.quantity_uom),desc:text(i.description)}:null; });
      const has=cells.map((c,i)=>c?names[i]:null).filter(Boolean);
      const lacksAll=cells.map((c,i)=>c?null:names[i]).filter(Boolean);
      const accepted=lacksAll.filter(nm=>okd.has(low(key+"|"+nm)));
      const lacks=lacksAll.filter(nm=>!okd.has(low(key+"|"+nm)));
      const present=cells.filter(Boolean);
      const desc=(present[0]&&present[0].desc)||"";
      const variant=isVariantItem(desc,cfg);
      const qtys=present.map(c=>c.qty).filter(v=>v!==null);
      const mn=qtys.length?Math.min(...qtys):null, mx=qtys.length?Math.max(...qtys):null;
      const avg=qtys.length?qtys.reduce((a,b)=>a+b,0)/qtys.length:null;
      const spread=(mn!==null&&mn!==0)?(mx-mn)/mn:null;
      const unitCost=cost.has(k)?cost.get(k):null;
      // what the gap is worth: the average utilization, priced, per product missing it
      const gapValue=(unitCost!==null&&avg!==null)?unitCost*avg*lacks.length:null;
      const spreadValue=(unitCost!==null&&mn!==null&&spread!==null&&spread>tol)?unitCost*(mx-mn):null;
      let state;
      if(!lacksAll.length) state=(spread!==null&&spread>tol)?"ALL_UTIL_DIFF":"ALL_SAME";
      else if(!lacks.length) state="GAP_ACCEPTED";        // every miss confirmed correct
      else if(!has.length) state="NONE";
      else state=variant?"GAP_VARIANT":"GAP";
      return { key, desc, variant, cells, has, lacks, lacksAll, accepted, min:mn, max:mx, avg, spread, state,
        uom:[...new Set(present.map(c=>c.uom).filter(Boolean))].join("/"),
        coverage:has.length/n, unitCost, gapValue, spreadValue };
    });
    // rank: the more products missing an item, and the more it is worth, the more urgent
    const sev=r=>{
      if(r.state==="GAP") return 1000*r.lacks.length + (r.gapValue||0);
      if(r.state==="ALL_UTIL_DIFF") return 500 + (r.spreadValue||0);
      if(r.state==="GAP_VARIANT") return 10;
      return 0;
    };
    rows.forEach(r=>r.severity=sev(r));
    const gaps=rows.filter(r=>r.state==="GAP").sort((a,b)=>b.severity-a.severity);
    const common=rows.filter(r=>r.state==="ALL_SAME"||r.state==="ALL_UTIL_DIFF");
    const utilDiff=rows.filter(r=>r.state==="ALL_UTIL_DIFF")
      .sort((a,b)=>(b.spreadValue||0)-(a.spreadValue||0)||(b.spread||0)-(a.spread||0));
    const variants=rows.filter(r=>r.state==="GAP_VARIANT");
    const acceptedRows=rows.filter(r=>r.state==="GAP_ACCEPTED");
    const acceptedPairs=rows.reduce((s,r)=>s+r.accepted.length,0);
    // per product: how exposed is each one
    const perProduct=names.map((nm,i)=>{
      const missing=gaps.filter(r=>!r.cells[i]);
      const value=missing.reduce((s,r)=>{
        const v=(r.unitCost!==null&&r.avg!==null)?r.unitCost*r.avg:0; return s+v; },0);
      return { name:nm, items:(products[i].items||[]).length,
        missing:missing.length, missingValue:value,
        carries:rows.filter(r=>r.cells[i]).length };
    }).sort((a,b)=>b.missing-a.missing||b.missingValue-a.missingValue);
    const priced=rows.filter(r=>r.unitCost!==null).length;
    return { names, rows, gaps, common, utilDiff, variants, perProduct,
      acceptedRows, acceptedPairs,
      total:rows.length, allSame:rows.filter(r=>r.state==="ALL_SAME").length,
      priced, unpriced:rows.length-priced,
      gapValueTotal:gaps.reduce((s,r)=>s+(r.gapValue||0),0),
      spreadValueTotal:utilDiff.reduce((s,r)=>s+(r.spreadValue||0),0) };
  }

  /* ================= COMMONALITY: parts shared between products ================= */
  function commonality(products){
    const n=products.length, map=new Map();
    products.forEach(p=>{
      const seen=new Set();
      (p.items||[]).forEach(i=>{
        const k=i.material_number; if(!k||seen.has(k)) return; seen.add(k);
        if(!map.has(k)) map.set(k,{ key:k, description:i.description, uoms:new Set(),
          drawings:new Set(), families:new Set(), products:[], qty:{} });
        const e=map.get(k);
        e.products.push(p.name); e.qty[p.name]=i.qty;
        if(i.quantity_uom) e.uoms.add(i.quantity_uom);
        if(i.drawing_no) e.drawings.add(i.drawing_no);
        if(i.drawing_family) e.families.add(i.drawing_family);
        if(!e.description) e.description=i.description;
      });
    });
    const rows=Array.from(map.values()).map(e=>({ ...e,
      uoms:Array.from(e.uoms), drawings:Array.from(e.drawings), families:Array.from(e.families),
      count:e.products.length, share:n?e.products.length/n:0,
      qtySpread:(()=>{ const v=Object.values(e.qty).filter(x=>x!==null&&x!==undefined);
        if(v.length<2) return null; const mn=Math.min(...v), mx=Math.max(...v);
        return mn===0?null:(mx-mn)/mn; })() }));
    rows.sort((a,b)=>(b.count-a.count)||String(a.key).localeCompare(String(b.key)));
    const fam=new Map();
    products.forEach(p=>{ const seen=new Set();
      (p.items||[]).forEach(i=>{ const f=i.drawing_family; if(!f||seen.has(f)) return; seen.add(f);
        if(!fam.has(f)) fam.set(f,{ family:f, products:[], revs:new Set(), items:new Set() });
        const e=fam.get(f); e.products.push(p.name);
        if(i.drawing_rev) e.revs.add(i.drawing_rev); e.items.add(i.material_number); }); });
    const families=Array.from(fam.values()).map(e=>({ family:e.family, products:e.products,
      revs:Array.from(e.revs), items:Array.from(e.items),
      count:e.products.length, share:n?e.products.length/n:0 }))
      .filter(e=>e.count>1||e.revs.length>1)
      .sort((a,b)=>(b.count-a.count)||(b.revs.length-a.revs.length));
    const shared=rows.filter(r=>r.count>1);
    return { total:rows.length, productCount:n, rows, shared, families,
      sharedPct:rows.length?shared.length/rows.length:0,
      universal:rows.filter(r=>r.count===n&&n>1).length,
      unique:rows.filter(r=>r.count===1).length };
  }

  /* ================= TEMPORARY PROCESS DEVIATIONS (TPD) ================= */
  const TPD_TYPES=[
    { id:"SUBSTITUTION", label:"Material substitution (stock-out)" },
    { id:"WEIGHT",       label:"Weight / gauge difference" },
    { id:"PACKAGING",    label:"Packaging change" },
    { id:"FASTENER",     label:"Fastener change" },
    { id:"PROCESS",      label:"Process change" },
    { id:"OTHER",        label:"Other" },
  ];
  const TPD_LABEL={}; TPD_TYPES.forEach(t=>TPD_LABEL[t.id]=t.label);

  function daysBetween(fromISO,toISO){
    const a=Date.parse(fromISO+"T00:00:00Z"), b=Date.parse(toISO+"T00:00:00Z");
    if(isNaN(a)||isNaN(b)) return null;
    return Math.round((b-a)/86400000);
  }
  function tpdStatus(t,todayISO,cfg){
    const warn=(cfg&&cfg.tpd&&cfg.tpd.warn_days)||2;
    if(t.closed) return { code:"CLOSED", label:"Closed \u2014 reverted to the BoM material", tone:"green", days:null };
    const due=text(t.extended_to)||text(t.due);
    if(!due) return { code:"NO_DUE", label:"No expiry date set", tone:"amber", days:null };
    const d=daysBetween(todayISO,due);
    if(d===null) return { code:"NO_DUE", label:"Expiry date unreadable", tone:"amber", days:null };
    if(d<0)  return { code:"EXPIRED", label:`Expired ${Math.abs(d)} day${Math.abs(d)===1?"":"s"} ago`, tone:"red", days:d, beam:true };
    if(d===0) return { code:"DUE_TODAY", label:"Expires today", tone:"red", days:0, beam:true };
    if(d<=warn) return { code:"DUE_SOON", label:`Expires in ${d} day${d===1?"":"s"}`, tone:"amber", days:d };
    return { code:"OPEN", label:`${d} days left`, tone:"green", days:d };
  }
  function tpdSummary(tpds,todayISO,cfg){
    const rows=(tpds||[]).map(t=>({ ...t, st:tpdStatus(t,todayISO,cfg) }));
    const by=code=>rows.filter(r=>r.st.code===code);
    const open=rows.filter(r=>!r.closed);
    const byType={}; open.forEach(r=>{ const k=r.type||"OTHER"; byType[k]=(byType[k]||0)+1; });
    const byProduct={}; open.forEach(r=>{ const k=text(r.product)||"(unassigned)"; byProduct[k]=(byProduct[k]||0)+1; });
    const expired=by("EXPIRED").concat(by("DUE_TODAY"));
    return { rows, open, closed:rows.filter(r=>r.closed), expired, soon:by("DUE_SOON"),
      noDue:by("NO_DUE"), byType, byProduct,
      needsAdmin:expired.length+by("DUE_SOON").length,
      extended:open.filter(r=>text(r.extended_to)).length };
  }

  /* ================= ECN impact on a SKU ================= */
  function ecnImpact(ecns,products,todayISO){
    const out=[];
    (ecns||[]).forEach(e=>{
      const refItems=text(e.items).split(/[,;\s]+/).map(x=>x.trim()).filter(Boolean);
      const hits=[];
      products.forEach(p=>{
        const keys=new Set((p.items||[]).map(i=>low(i.material_number)));
        const fams=new Set((p.items||[]).map(i=>low(i.drawing_family)).filter(Boolean));
        const matched=refItems.filter(ri=>keys.has(low(ri))||fams.has(low(drawingFamily(ri))));
        if(matched.length) hits.push({ product:p.name, items:matched });
      });
      const d=text(e.effective)?daysBetween(todayISO,text(e.effective)):null;
      out.push({ ...e, refItems, hits, impacted:hits.length,
        timing: d===null?"":(d<0?`effective ${Math.abs(d)} day${Math.abs(d)===1?"":"s"} ago`
          :d===0?"effective today":`effective in ${d} day${d===1?"":"s"}`),
        overdue:d!==null&&d<0 });
    });
    out.sort((a,b)=>b.impacted-a.impacted);
    return out;
  }

  /* ---------------- CSV / table helpers ---------------- */
  function parseCSV(str){
    const rows=[]; let row=[],field="",i=0,q=false;
    str=String(str).replace(/\r\n/g,"\n").replace(/\r/g,"\n");
    while(i<str.length){ const ch=str[i];
      if(q){ if(ch==='"'){ if(str[i+1]==='"'){ field+='"'; i++; } else q=false; } else field+=ch; }
      else { if(ch==='"') q=true;
        else if(ch===","){ row.push(field); field=""; }
        else if(ch==="\n"){ row.push(field); rows.push(row); row=[]; field=""; }
        else field+=ch; }
      i++; }
    if(field.length||row.length){ row.push(field); rows.push(row); }
    return rows.filter(r=>r.some(x=>text(x)!==""));
  }
  function toCSV(rows){
    return rows.map(r=>r.map(c=>{ const s=text(c);
      return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s; }).join(",")).join("\n");
  }
  function tableToObjects(rows){
    if(!rows.length) return { headers:[], objects:[] };
    const headers=rows[0].map(h=>text(h));
    const objects=rows.slice(1).map(r=>{ const o={};
      headers.forEach((h,j)=>o[h]=r[j]!==undefined?r[j]:""); return o; });
    return { headers, objects };
  }
  function autoMap(headers){
    const norm=h=>low(h).replace(/\s+/g," ");
    const H=headers.map(h=>({raw:h,n:norm(h)}));
    const map={};
    for(const f of LOGICAL_FIELDS){ let hit="";
      for(const a of (ALIASES[f]||[])){ const m=H.find(h=>h.n===a); if(m){ hit=m.raw; break; } }
      map[f]=hit; }
    return map;
  }
  function findHeaderRow(rows,limit){
    limit=Math.min(limit||15,rows.length);
    const norm=s=>low(s).replace(/\s+/g," ");
    const all=new Set(); for(const f in ALIASES) ALIASES[f].forEach(a=>all.add(a));
    let best=0,bestScore=-1;
    for(let i=0;i<limit;i++){ let sc=0;
      for(const c of rows[i]) if(all.has(norm(c))) sc++;
      if(sc>bestScore){ bestScore=sc; best=i; } }
    return bestScore>=2?best:0;
  }
  function applyMap(objects,map){
    return objects.map(o=>{ const r={};
      for(const f of LOGICAL_FIELDS) r[f]=map[f]?o[map[f]]:null; return r; });
  }
  function fmtNum(n){
    if(n===null||n===undefined||n==="") return "";
    if(n===Infinity) return "n/a";
    const v=Number(n); if(isNaN(v)) return text(n);
    if(Math.abs(v)>=1000) return v.toLocaleString(undefined,{maximumFractionDigits:2});
    return String(Math.round(v*100000)/100000);
  }
  function round2(x){ return x===null||x===undefined?null:Math.round(x*100)/100; }
  function pctStr(x){
    if(x===null||x===undefined) return "—";
    if(x===Infinity) return "n/a";
    const p=x*100, sg=p>0?"+":"";
    return sg+(Math.abs(p)>=10?p.toFixed(0):p.toFixed(1))+"%";
  }

  const FLAG_LABELS={
    MATCH:"Agrees with NAV",
    FAMILY_MISSING:"Missing from a product in the family",
    FAMILY_UTIL_DIFF:"Utilization differs across the family",
    FAMILY_PART_DIFF:"Same part, different part number",
    VARIANT_PART_DIFF:"Variant item \u2014 different part number",
    VARIANT_MISSING:"Variant item \u2014 expected to differ",
    VARIANT_UTIL:"Variant item \u2014 utilization differs",
    MISSING_IN_NAV:"Consumed on floor, not in NAV",
    MISSING_ON_FLOOR:"In NAV, not found on floor",
    SUBSTITUTION:"Material substituted",
    DOSAGE_MISMATCH:"Utilization differs materially",
    SCRAP_NOT_IN_NAV:"Scrap on the floor, no scrap factor in NAV",
    SCRAP_UNDERSTATED:"Floor scrap above the proposed factor",
    SCRAP_OVERSTATED:"Floor scrap below the proposed factor",
    DOSAGE_WARNING:"Utilization differs slightly",
    UOM_MISMATCH:"Units not comparable",
    UOM_UNKNOWN:"Unrecognised unit",
    UOM_CONFLICT:"Mixed units within a BoM",
    PARTNO_MISMATCH:"Part number disagrees",
    MATERIAL_DIFFERS:"Different material description",
    REV_MISMATCH:"Revision in use differs from approved",
    DRAWING_NO_MISMATCH:"Different drawing in use",
  };

  const API={ DEFAULTS, LOGICAL_FIELDS, ALIASES, HARD, DRAWING_FLAGS, CAPTURE_FLAGS, FLAG_LABELS,
    familyKey, familyPairKey, descSimilar, isVariantItem, familyCompare, crossCompare, commonality, TPD_TYPES, TPD_LABEL, tpdStatus, tpdSummary, ecnImpact, daysBetween,
    toFloat, text, low, uomDimension, relDiff, signedDiff, normQty, deriveDrawing,
    drawingFamily, revFromNumber, prepare, compareBoM, computeHealth, buildActions, buildSummary,
    DISPOSITIONS, DISP_GROUP, DISP_LABEL, suggestDisposition, effectiveDisposition,
    buildChangeList, changeListCSV, OVERRIDE_REASON,
    parseCSV, toCSV, tableToObjects, autoMap, findHeaderRow, applyMap, fmtNum, pctStr, round2 };
  if(typeof module!=="undefined"&&module.exports) module.exports=API;
  root.BOM=API;
})(typeof window!=="undefined"?window:this);

