
/* Self-contained .xlsx reader -> array of rows (each an array of cell strings).
   Uses fflate (bundled) for unzip and the browser's DOMParser for XML.
   No network. Works in Node tests when fflate + DOMParser + TextDecoder are global. */
(function (root) {
  "use strict";
  function readXlsxRows(bytes, deps) {
    deps = deps || {};
    const zip = (deps.fflate || root.fflate);
    const DP = (deps.DOMParser || root.DOMParser);
    if (!zip || !zip.unzipSync) throw new Error("unzip library unavailable");
    if (!DP) throw new Error("DOMParser unavailable");
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const files = zip.unzipSync(u8);
    const dec = new TextDecoder();
    const parse = (name) => files[name] ? new DP().parseFromString(dec.decode(files[name]), "application/xml") : null;

    // ---- shared strings ----
    const sst = [];
    const sdoc = parse("xl/sharedStrings.xml");
    if (sdoc) {
      const sis = sdoc.getElementsByTagName("si");
      for (let i = 0; i < sis.length; i++) {
        const ts = sis[i].getElementsByTagName("t");
        let s = "";
        for (let j = 0; j < ts.length; j++) s += ts[j].textContent;
        sst.push(s);
      }
    }

    // ---- choose the first worksheet ----
    let sheetPath = null;
    const wb = parse("xl/workbook.xml");
    const rels = parse("xl/_rels/workbook.xml.rels");
    if (wb && rels) {
      const sheets = wb.getElementsByTagName("sheet");
      if (sheets.length) {
        const rid = sheets[0].getAttribute("r:id") || sheets[0].getAttribute("id");
        const rl = rels.getElementsByTagName("Relationship");
        for (let i = 0; i < rl.length; i++) {
          if (rl[i].getAttribute("Id") === rid) {
            let t = rl[i].getAttribute("Target");
            if (t) { t = t.replace(/^\/?/, "").replace(/^xl\//, ""); sheetPath = "xl/" + t; }
          }
        }
      }
    }
    if (!sheetPath || !files[sheetPath]) {
      const cand = Object.keys(files).filter(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort();
      sheetPath = cand[0];
    }
    if (!sheetPath) throw new Error("no worksheet found in workbook");

    // ---- read cells ----
    const colIndex = (ref) => {
      const m = /^([A-Z]+)/.exec(ref || ""); if (!m) return 0;
      let n = 0; const s = m[1];
      for (let i = 0; i < s.length; i++) n = n * 26 + (s.charCodeAt(i) - 64);
      return n - 1;
    };
    const sheet = parse(sheetPath);
    const rowsEl = sheet.getElementsByTagName("row");
    const out = []; let maxCol = 0;
    for (let i = 0; i < rowsEl.length; i++) {
      const cells = rowsEl[i].getElementsByTagName("c");
      const row = [];
      for (let j = 0; j < cells.length; j++) {
        const c = cells[j];
        const ci = colIndex(c.getAttribute("r"));
        const t = c.getAttribute("t");
        let val = "";
        if (t === "inlineStr") {
          const ts = c.getElementsByTagName("t");
          for (let k = 0; k < ts.length; k++) val += ts[k].textContent;
        } else {
          const v = c.getElementsByTagName("v")[0];
          const raw = v ? v.textContent : "";
          val = (t === "s") ? (sst[parseInt(raw, 10)] || "") : raw;
        }
        row[ci] = val;
        if (ci + 1 > maxCol) maxCol = ci + 1;
      }
      out.push(row);
    }
    // normalise widths + drop fully-empty rows
    const rows = out.map(r => { const a = []; for (let i = 0; i < maxCol; i++) a[i] = r[i] != null ? r[i] : ""; return a; })
                    .filter(r => r.some(x => String(x).trim() !== ""));
    return rows;
  }

  // read every worksheet: a change-request workbook holds one form per sheet
  function readXlsxSheets(bytes,deps){
    deps=deps||{};
    const zip=(deps.fflate||root.fflate);
    const u8=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);
    const files=zip.unzipSync(u8);
    const names=Object.keys(files).filter(k=>/^xl\/worksheets\/sheet\d+\.xml$/.test(k))
      .sort((a,b)=>(+a.replace(/\D/g,""))-(+b.replace(/\D/g,"")));
    const out=[];
    for(const n of names){
      try{
        const sub={};
        Object.keys(files).forEach(k=>{ if(!/^xl\/worksheets\/sheet\d+\.xml$/.test(k)
          &&k!=="xl/workbook.xml"&&k!=="xl/_rels/workbook.xml.rels") sub[k]=files[k]; });
        sub["xl/worksheets/sheet1.xml"]=files[n];
        out.push(readXlsxRows(zip.zipSync(sub),deps));
      }catch(e){ /* skip a sheet that will not parse */ }
    }
    return out.length?out:[readXlsxRows(u8,deps)];
  }
  const API = { readXlsxRows, readXlsxSheets };
  if (typeof module !== "undefined" && module.exports) module.exports = API;
  root.XLSXREAD = API;
})(typeof window !== "undefined" ? window : this);

