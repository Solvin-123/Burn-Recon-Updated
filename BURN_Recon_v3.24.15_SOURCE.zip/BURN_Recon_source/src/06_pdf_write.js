
/* Minimal offline PDF writer (no dependencies). Multi-page A4 landscape/portrait,
   Helvetica + Helvetica-Bold, headings, key/value blocks, wrapped paragraphs,
   clipped tables with header shading, page numbers.
   build({title, subtitle, meta:[[k,v]], landscape, blocks:[...]}) -> Uint8Array
   blocks: {t:"h1"|"h2"|"p"|"kv"|"table"|"space"|"rule", ...}                       */
(function (root) {
  // Burn Manufacturing logo, embedded as a JPEG so every report carries it
  const LOGO={ w:239, h:64, b64:"/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCABAAO8DASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7+rirr4s+ArL4iL4Kudfgj1QjnJ/dK56Rl+gf2q38RrLxXqHw11S18F36WWstF+5lbgkfxKpP3WIyAexr87ZRJ9ok88sZd53l2yxbPJJ7nPemkI+8PiD8ZPAvhfR9R05/EcL6qbeRIoLT966yFDtyV4HJHevA/gf4M8Z/EjVX1XWvFviKHw/ZuFlKajMGupOpjU7uAO598Vz3wo+FLfEXwd4vuwjrdWcMY0+cE83Ay5Qj+IMuAfQkV9hfDzwvD4O+GWjeH4oRHJb2y+fjqZWG6Qk9/mJ/DFAFS5+IngTw34rj8FahrkOn30UUZjiumYKVbhf3jdT9TUes/FrwBoPi2y8N6j4htlvrsgAIdyRZ+75jDhc9q8A/aw8KzW/i7S/FscGba8h+yTP1xInK59Mqf0r51bnJYk56knOaLBc/T5WDKGUggjII70teS/s8Wvi+D4PWs3ijURdW8+JNOjY75IYMcBm757DsK9apDPM/in4v13wtqGk/2PcxxLKJGkR4w4fGMZ79+1dJ4F8XL4w8Nm9a38i5hfyp0Byu7Gcr7GvP/jp/x/6J/uy/0rV+B3/Ir6n/ANfY/wDQBXxmHzDELP6mG524NbdF7qenY+xr4Cg8hp4nlXOnv395rXuep0VUudV0yzm8m71G1gkxnZLKqnH0Jp1vqFhd/wDHre28/wD1zkDfyr7D2sL8t1c+R9nO3NZ2LNFFFWQFFFFABRRRQAUUUUAFFFMaWJDh5EU+hIFDdgSuPoqL7Rb/APPeL/voVKCCMg5B7ikmnsNprcKKKQugPLD86YhaKAQehBooAKK5G7OqReMb5E1a7+zRWP2xIdq7d2WG3OOnA4rC0nxF4on/ALHt7t5AYl3Xk3lYFx5kRePHpgdfcV5c81hTmoSg9Xbp0aXf5+iZ6cMrnUhzxktFfr1Tfb5erRwHxT/aI8LT+AdY0HwneXr6zOGtBJ5JjWEE7Xbce+MgY9a+ToIJri5itbaMyTSuscaDksxOAPzNdT4w8E+L9C1TUtR1jw1qdlZ/an/0maBhF8znb8/TmsrwrPFa+PdDuZ3CRRahbu7N0UCQZNeseUfe/wAMPBVt4A+GeneH4gpnVPNupAMGSZuXP9B7AV2FeYeDfET+OPjR4ou1ui2meHGTTrOBG+VpXUtLMccE8BR6AH1r0+pKMHxl4T0zxt4KvvDerR7oLqPCuB80TjlXX3B5r88fEGh33hrxTqGgakm26sZ2gk44ODww9iMEfWv0sr4K+Pl1a3f7QviKS0dHVJI4nZDkF1iUMPqDwfpTQmehfA/47+H/AAZ4Ck8N+Mbq7RLaUvZyxxGUCM8lDjpg5x9a+qtPvrfVNItdStGLW9zEs0TEYJVgCOPoa/N/SPCfifxNBOfD3h/UdUWP5Ha0gaQIxHAYjpX6IeEbW4svAGiWd3E0M8NhBHJG3VGEYBB+hoYI8w+On/H/AKJ/uy/0rV+B3/Ir6n/19j/0AVlfHT/j/wBE/wB2X+lavwO/5FfU/wDr7H/oAr8+of8AJTT9P/bEffVv+Sah6/8At7JPiX8N7vxHfx63ovlNeBBHNBI20SAdCD2IryjVfCXijwuEvL/Tp7RAwC3ML5Cn/eXpX1NWX4ltYb3wdqltcIrxtaycEZ5Ckg/gQDXp5vwthsU54mDcZvXyv/wfJnm5TxRicMoYaaUoLTzt/XkecfC74hXupX6+HNdn8+ZlJtrl/vNjqjepxyDXrdfKPhSZ7fxvpE0Zwy3ceP8AvrFfVx6UcIZhVxeFlCs7uDtfyYcXZfSwuKjOirKavbzPAfiVrWr6T8XJ59N1K5tnjiiKhJDt6d16EV7F4P1ufxD4J0/V7mNY5p48uE6ZBIJH1xmvDvi3/wAlTu/+uMX/AKDXrvwu/wCSUaR/uP8A+htXFkOIqf2xiqLk+X3nbpfmX+Z255Qp/wBj4aryrm91X8uVnYVwfxU8Vah4a8MwJpbeVdXkhiE+MmNQMkj36YrvK8k+On/IJ0b/AK+JP/QBX0PENedDL6tSm7O2/q0jwOH6MK2YUoVFdX29E2Q/BS9vbzUtZe8vLi4YrGxMshfnJ55r2GvF/gX/AMf+sf7kf8zXsdy7R2U0inDKjEfXFcvC028shKWvxfmzo4nilmc4x/u/kjxX4ifEzUpNZuND8P3TWttAxjluI/vyOOoB7AdOK8+g0nxHrafa4bDUr9egmIZx+BNVLVDf61BFM2Tc3Chz67m5/ma+tbS1gsrGK0tYlihiUIiKMAAV8jl+CrcR1qtbEVWorZeuyXRW/E+tx+MpcO0adHD005Pd+m7fV3PmfS/h74r1bUo7MaRcWqMfnnuF2og7k+v0r6CmnsPBngUSXEjG20+3C5JyzkDAHPcn+dblea/Gudk8CW8AyBLdrnB9ATX0tLK6OQYStiaLcp23f4fifN1Mzq59i6OHrJRhfZfj+B5fr3jvxR4n1IqLu5ghdsRWVoxUD0HHLH3pq+D/AB/MolGkau27nLSHJ/Nq6L4K2lvceN7u4miV5Le13RE/wktgke+K96rwsoyGWcUXjMVWldt7eXr+SPczbPY5RWWEwtGNkl+Pp+bPlm4Txl4WuI5bptX018/IzSMFJ9OpH4V658M/iHceI5H0XWmQ6gib4plG3zlHXI/vD2rq/G2n2upeANWguowyrbPKp7qyqWBH4ivnz4fzSRfEvQ3Ripa4CnHcEEEUTpVsgzGlTpVHKnO2j9bPy03TCFWjn2X1alWmo1IX1Xpf112aPqKiiiv0k/OTmPiLpOi638Ldc07xDcx2unyWjmS5kOBCQMh/wIB9+nevzpICuQr7wDw4GN3PXHb1r9HfGvg/SfHfgy78N6yJRbXAB3xNtZGHKsPoexr49vP2dfiFD8Rm8M2lmtxaH94mrt8sHlZxub0b/Z6/hTQmV/gb8U4fhx41uTrBlfR9SVUumTLNE6n5Zcd+pB74+lfYNr8SfAN5pZ1G38X6Q1uACWa5VSM/7J5/Svjjxh8BPiJ4R864OljVdPiBY3lidwCgEksn3hgA57V5ftQjO0HNAH2P8Sf2lPDeiaZcad4KnTV9WdSi3Cj/AEe3P94k/eI7Ace9fH1zcXF3dzXd1M89xM7SSSOcs7E5JJ9Sa7Twb8IfHnjmGK50PRWWwkOBfXLCOHHcgnlvwBroNb/Z2+I+k+K7LR7awj1KG8bbHf2x/cx+pkzymPfr2pgfRn7OekaJpnwQsZ9IvY7yW8dp7yVRgrL0KEdRtGBzXrVcH8Kvhjp3wx8JNp1tcSXV7csJby5YnDyAY+Veyiu8qRnlXxu0ia40Kw1iJCy2khSXH8Kv3/MVyfwt8bWHhi7u7DV3aKzuirrMBkRuOOR6Ed/avfLm2gvLOW1uollhlUo6OMhge1eQa78E3a7ebw7qMccTEkW9yD8nsGHb618TnOVYyjjlmWAXM+q+VvmmvmfaZPmmDrYF5bj3yro/nf5NP5Hoa+OfCDKGHiGxweeZMVzfjT4l+Hrbwzd2WlX0d9e3ETRIsOSqbhgsT7AmvPz8GfGGeF08+/m//Wq3Y/BTxHLMovr6ytY88lCXOPYVjWzXPK8HSjhuVvS9n+rsbUcryShNVZYnmS1tdfornN/D3SJtX+IemwxoWjgkFxMeyovPP1OBX09XP+FPB+k+EdNa309C80nM1zJ9+Q+/oPaugr3OHMolluGcKj9+Tu/LyPE4izaOZYlSpr3Iqy8/M8C+M+mT23jqLU2U+RdwKqtjgMnBH15BroPhf4+0ay8MR6BrF3HZy2xbyZJOFdCc9fUZNekeIPD2meJdGfTdUgEkbcqw4aNuzKexryDU/gjrMU7/ANl6la3MP8InBRvx7V4eNy7H5fmEsfgYc6le69d19+qse3gsxwGYZfHA42XI47P02/DR3PVf+E38Jf8AQwWH/f0V5B8V/GOmeJL2ysNIk8+C0LO84BAZzxhfUYHWoP8AhTPjDP3dP/7+/wD1q3dE+CVwbtJdf1OPyVIJgtQct7Fj0rHG4jOs0pPCvD8ie72/M2wVDJssqrFLEczWy3/I0fghpk0OiajqsibY7mVY4mPVgo5P0ya9RvP+Qdcf9c2/lSWVna6fYRWVlAkNvEoRI0GAoFPnjMtrJEDguhUE+4r7DLcB9RwcMMndpfi9X+J8hmOO+u4uWIasm/wWi/A+S9G/5GPTv+vmP/0IV9cDpXlXhH4Px6Vq8Wp65epdSQPvighGEyOhYnr9K9VrxOEsrxGBo1HiFZya066Ht8V5nh8dWgsO7qKevqFeX/G7/kT7H/r7H/oJr1CuM+I/hTUfFmg2tlp0kKSR3AkYykgbcEV6+e0KlfAVadJXk1ovmeRkdaFDHUqlR2inqzz74H/8jdqf/Xov/ode6VyXgbwNaeDdPlxN9pvp8edORgYHRVHYV1tZcPYGrgsDCjW0lq/S7NeIMbSxuOnWo/DovuRleJv+RK1f/rym/wDQDXzf4D/5KRoP/X0lfUM8EVzay206B4pUKOp6MCMEV5TZfCS70X4hafqumXsUunQXAlMcuRIijPHvXlcR5ZiMTisPXoxuotX8tU7nqcO5lh8PhsRQrSs5J289GrHrVFFFfYHyIUUUUAVtRsotS0i706YkR3MLwuR1AZSD/Ovnsfsi+HQMDxhqoA6fuI6+jaKAMDwV4VtfBPgTTvDFncy3MNlH5azSgBn5JyQPrW/RRQAUUUUAc74v1O90u00t7Gbymn1S2t5DtB3I74Yc+oqtfeIb60/4Sl7RJL+XTI43itFjVNpaPdwxPzepzjpitHxJos2t22nxwzJEba/gu2LjO5Y2yQPc1XHh64F/4ln+0R41aJEjGD+7xEU5/E5oA53w94q1DSvAlrqHiKLWLvUb94ktoJfJL3UrpuxEqYCp1PzHgDk10nh7xSutX11pl5pl3pWqWqrJNZ3O1jsbO11ZSQynBHsRWR4k8DTaz4R0GyjmtmvdFkhmjW4UmGZkjMbKwHIBBOCOhxV7wp4fk0q8ury40TSNOllRYwbJnd2UZ4Zm6jngUAdRkbtuRnriub8SeLhoerWWj2elXOqaneI8sVtC6R/ImNzbnIHccDJNa/8AZNl/wkH9teW32zyfs+/ecbM5xjp171heM9Cvddjggi0bRdTt1DZXUCyPG/ZkZQcY7jg1MXJ35kVJRVuVmhq2uXuneHodRt9CurqaQKWtfNjiaLIydzMdox0rIt/iPpEuhzajPbXVubS9jsL6FtrNaO+MMxUkFPmU7gehrLuPAWt/2F4YiudSg16fR4nSe31LIiumYDa+RnDJgBSc8E96t6B8P47bSvE8Ori2B8RTmWa2tBiKBfLEYCk8k/LnPrVEm/d+I7ZPEN1oUAlNzb2BvZZkUMkKkkKDzyxwSB6Csr/hNHg8N+H3t9OvdZ1HVrIXMMcCJEXARWZmycJ98cc9aTwl4P1HRfDmpprOpx6jrOokie8VNoKKnlxKB6BQM+pJNTaX4UurCXwm8l1E40XTnspcA/vGZI13L6D92fzoAfb+OdPHhjUdW1WzvNMk01/Ku7SdQ0iuQCqrtOH3bl2465o0jxjNeeIodF1bw9qGjXN1HJNafaSjrMiY3cqTtYblOD61U1/wfFqOi+JEv71YYr2aK8ilVCxgaFUKsR3wyA49K5bwz4h1Txb8V9EuhfaVqllYWd0JrrS4pQkbv5YAdn4BODhRzwaAPXCQCMkDPSsLxT4ot/DFlau9rNd3V7cC1tbaIqplkKlsbmIVRhTya0bvSrK+1CzvbiNmms3LwkOQASMHIHX8az/Fem3eq6Ktnb6bpeoxs+ZrbUchHXB6EA4Occ4qYuV3dadCpKNlZ69TnvGXjTX9E+G0WvWnh6eG9e6hge2nZH8oNIqkkhsHIOAR3IrV1Hxk9hHYWi6FfXGtXsbyx6XEyb1VCNzO5O1QMjnPUiufT4eau/wt1Dw9NqUIuJ78X9pCCzQWgWRXSBSfmKAr1/2jitq/0fxJLrOmeKLI2KanBbSWtzYyOxhlRyG+V8ZDAqOccgmqJD/hYFjDot7e6hpt9ZTadPFDqFrKoL2yyEYlO0kNHg53DsD6VqXXijTrTxONFfeXSye/uJhjy4IlOAWPvzj6GszSfCU0s3iDUPEv2Wa51xFgngtwTHHAiFVQE9T8zEn3ql4b+H01j4U1jTfEGpDUbvU4jZyXSAqRbqhjiXnuFPJ7nJoAtWHj4XWoWAu/Duq2Gn6k6xWV/cKuyVmBKhlB3JuA4z14HeprPxodT8YXWj6Zod7dW1ncmzur9XjVIZQASNhO4gAj5sd6wtC8B31hLplpqGieHLiKyeMm+HmeZJs+6yxnhX4U5yRnNS654M1vWPGMWo28Ok6ZJFeJMNXtC63TQqQTEy4wxYZBJOMHpQB6HRRRQB//2Q==" };
  /* The gear-and-flame mark, alongside the wordmark, so a printed report carries
     the same identity as the screen. Embedded as a JPEG for the same reason as the
     wordmark: the file has to work with nothing to fetch. */
  const MARK={ w:192, h:192, b64:"/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCADAAMADASIAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAcBBAUGCAMC/8QANRAAAgEDAgQFAgQFBQEAAAAAAAECAwQFBhEHEiExEyJBUWEycRRCgZEVFzNygjQ2UlRjwf/EABwBAQACAwEBAQAAAAAAAAAAAAAHCAQFBgMCAf/EADQRAAEDAwIEAwcCBwEAAAAAAAEAAgMEBREGIRIxQVETYXEUIjKBkbHRB8EVFiMzQlKh8P/aAAwDAQACEQMRAD8A2AAFVFdBAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAKbrfbmXN/wAfU/UVQPv0HX0TZ+IvG7uqFlbyurmXLSh1bNZlxP0RGUoSyD3i9n0LniDc/g9JXVZvZ9tmc9uNKe9V0o+bzdiQdI6Upb7TPqKpzhh2BwkD7hRhrjWtbpyrjpqNrTlvEeIE/YhT3/NDQ+2/8Rf7GWwep8LqLmWIrTnydW3HZEM6I0DPVFeNzXoKFnF9Xt3JvxeIx2GtYWmPtoU4xWzkls2YWprXZbOTTUr3vm65IwPXbn5LP0heNQX0CrrGMZB0wDxO9N9h5q9A2fom/wBBucYpAQFH79l7hNPqmmvdBFUAH4iAAIgACIAAiAAIgBhNWalpaXxU8jVoSqfljt6M96amlrJmwQjLnHAHmserq4aGB1TUOwxoyT2C+9S6nx+mbKV1eVE6rXkp+u5D0+JWoXmZZOnUSg31h6cpg83ncjn72V9kKzk5Pyx36JGPJw0/o6ktlOfa2h8jhvnkPIflV21Prytu9UDROMcTDluNiT3P4U6af4lYTLWjqXEvCrUl51Lpv9jCZ7jDaUnKhhKT8SPRykujIl29pSX2ZeYfHvLZSjjIyUJVu0mebdDWeklfVSAlg34Sdh39V7P/AFFvtbCyjhIDztxAbknl6FZPO631BqKk7fJTj4T/ACxLXTWCuNQ5aljLdbJNOT9OUpn9P3+nrx2l5Teze0J7dGShwl07GxxksrcR3uJvyv4My63OjsVnNRQBoDvg4eWT1/K19mtFdqS+imuRcS3d5dzwOnz6LdcRirXDWFOws4KMIrzfLLi6k6dpWqR7xi2j1+fc+KtPxqNShvt4i2IGdK6WXxJTkk5J+6so2FsMPhQjAAwAOm2yh2pxT1FjcvWtq3JK3hLZe5umB4m4HL0+Wo3RqxXm5uzIh1Zauy1LeWsu8G2Yh/EnH+3oTjNo+1XWljkYzgcWg5btzHUdVXan13erLWSxPf4jQ5w4Xb8j0PRSbrLipUrSnj8B5YR6Tm/V/BTQnEyrRqLG56fMpvZT9iNB+uz9zN/lC1+wmhEe3+3+We+Vr/55vP8AERcTJv8A6/447YXUdOpTq041qNRTpzW6kux9EMaA4g3eKr08Tf8ANXt6klGC7tMmaL3jGW23Mt0QvfbFUWGo8Gbdp+E9x/7mp+03qOm1JS+PBs4bOb2P47KoANGuiQABEAARAAEQs8pi7TMWU7C9pqcJrZb+jLw861aFCjUr1JJRpx5v2PSJ743h0Zw4HbHPK8pmRyRuZKMtI3zyx1yueNWaaudM5WpZ1PNSk+aE/j2MKZ3Weoq2o83VuXLajTbgoGCLM2w1Jo4zWf3MDPqqi3cUja6UUOfC4jw57fhDY+H2Pq32q7ScYt0oPzNehrcpcseZ+hM3CTTrxuNqZG5hvK681NtdkarVVzba7XI8/E4cI+fP6DdbrRdodeLxFGPhYeJx7Abj6nZZfiNp9ZzCONCipXVKceRpdUjNYGx/h+HtbXbaUaSU/vsX22669SpAz7hM+iZQuPutcXD5/srJx2uCOvfcWj33tDT8iTn1Qb7NS9gDAWyUP8XtPStL2GZoQcvxD87S7EddPQ6S1Fh6WcxNexnBOpOLUH7M52yWOrYm/rY6tFqVGTW79ScdCXoV9D7JIf6kf/W9D8uSrt+o9gNsuPtsQ/py7+juo+fNWw+F3fYD5Xddvud0o4Uq8MdC01BZ/KQUm/6dN+nySh/87Ed8JtTu/tHg7mfNXpLm3fsSIiverpKx91kbWHccu3D0wrQ6HioGWWJ1ANiPe78XXPogAOYXXoAAiAAIg79gVh9f6MHYIsXc6kwlnKVO4u4xlHpJb9jUdc69wssHVtcXduV1N7KK9iLNQ1rh6iycXczaVZ7Lft1Mc+r3fV+5M9q0DSQOiqpJC4jDsdOQOCoCvX6l11S2ajhia0HibnrzIyPNN925PvJ7v7gDfbr7EiKLFltLYarm81b2sYc1HmXi/COibO0pWFrSsaP9OjFKJGfBbGwg7u9nHdz+lv0JMuLmjaW8rm5qKFOPdtkI69uT625exs+GPAA7k/v0Vhf01tMdvtPt8nxS5JPZo6enVewLPGZOhlKU61vFqEX0b9S8OFkjdE4seMEKR4pWTMEkZyD1QAHwvROq6ruRpxY0krmgs7Z00nR61dvUkst7+yp5Gyq2NVbwqRe6NtZbpJaK1lUw8jv5jqtLqCzxXy3yUcg5jbycOS5hT5kpe5Uusvb/AITMXtoltGjUaX7lqWSjeJGB7eRAP13VTJI3RPMbuYJH0OFmdIZpYDNwvnJxjNpTfwTdb630xc7eDfLtuzngc9SEX4dRw+xzF+0nS36Vs8ji1wGNuvr6LsNNa2rNNQup4mB7Cc4PT09V09aX1pfQ8W0qqcfdM9yPeD9SrOwreJVlPp6kgx+lEI3igFsrZKRpyGnmrDWG5uvFvirXN4S8clUAGsW3QABEKw+v/FlAntLf42B3CLmnUH+5Mov/AGZYbNd0StmOD13kL27vbfIQpzuJua39DVNScNsvpey/H3F0riCez5Sw1s1NaapsVPHMOPDRjfOcBVcu+kb1RvlqZac+GC52dsAEnzytUKS6pgr69TpVyXNTHweqc+Pq0/ZFnrPPVNQaktdJWFRqk5JV3EwfDHUccRQyMLiaTcX4e5aaLrfi+IcLupPeVSTfX1Izls5hu1bcZB/bbxM7cRHP5fdS7BfRPZLfaonY8V4a/vwh3L5/ZTdY2dPH2dGxpJJUYqO69T3Ky+uX3KEROeZDxu5nf6qcWMbG0MYMAbD5IAD5X0gj9X+LBaZW/hjMdXyE2lGlF9T7ZG6VwjZzOw9SviSVsLDI84AGT6Bc+6vlSlqK98JdVUfN+5hy4ydz+Myl3ep7qtNyX7luWgo4zDTxxnmGgf8AFTyulE9VLK3kXOP/AEoUknyvoXFjZVsjdQtLdeeo9l8G+W3BTM1IxqVspTUZJNxMSvvVBaiBWShhPLOd/os22WC5XkE0MJeBzIxgfVZ/g7/oK32JCj9KNe0dpWWlaE6Mqyqc/sbElstiAdQ1cVdcpaiA5a47FWZ0tRT260Q01QMPaNwgANKugQABEAARU2+X+5YZzGQyuKr2U0muRtb+5kCjaScpNKMest/Y9YZXwyNkYdwcheU8LJ43RSDLXDB9CuYr+0r2F7XtLmm4TjN7J+x4G3cTr3G3uo5VMc4yUVyzkvc1EsxbKp9bRx1EjeFzgCR2VRbtSR0FdLTRP4mtcQCOoX1CpOnvyScd++xf6dyKxWetsnUlsqckmzHFGk1s1ujJmhZPG6J/JwIPoViQTvppWTMO7SCPUbrp+zuoXtpRvKbTjWipbo9yFNCcRa+C2xuTk6ttLtN/kRK1hqjAZGmqtpfxkn8lfb5pqss87mlhczo4DIx+ys/p3VtBfaZrw8Nk/wAmk4OeuO4WVB4SvrKEeaVxDb+4xOS1rprGwlKvkY867R37s0sNFUVLuCGMuPkCugqK+lpW8c8rWjzICznRptySiu737ETcT9cRu3LBY2pvTXSs0+5Y6s4p32WjKxxcHb01uvET+o0KUpTnKpUk5Tl1lJ+pKek9GSUkorriPeHwt7HuVDOttfx10Lrdaz7p2c/lkdh+5VEtoqK9A+ibfoVC2TTfZd0ScogUgcIsC7zKVMvXp81vFbRbXTcmTbf9DUeGd7i6+n4W9hywqR+qC7/c28r3q6vmrrrIZQW8PugHsPyrQ6HtsFussTYXB3F7xI7np8kABzC69AAEQABEAARDWtf1s1R09UeFpuVTrzNd+U2UpJKScZrmi+6fYyqKoFJUMnLQ7hIODyKw7hSmupZKYPLC4EZHMZ6rluUpznOVRSVRvz83fcEtcQOG8bpTzODpqNZLedNLpsRPKnVjUdKVGfiRezht13LE2a9Ut7pxNTnccx1B/HYqrF/0/WaeqjT1QyD8LhycPLz7hfINxwHDLNZmyneTiqXMt6Sl0/cwmZ0rnMDVdO+tZT29YLdHtDeKCondTRytLx0yvCew3Kmpm1csDhG7kcfdYhpNbPqj0pXFzbra2rypL2TPhxmvrpyh8SQNiQHDB3C1QJacjY/RXLyuYa2llKrXtuy3qznXe9xJ1H7yZQHy2NjDlgA9AAvp8skgw9xPqSfunpsD7pULitNU6VpVm5PZOKNuwvC7UWTgritGNOk1uk+jMStuVJbmcdVIGjzKzbfaa26v8Ojic8+Q5LTgZTP6cymnbyVtfUJOLflml02PvTmmshqW+jaWdN8n55vskfZr6YU/tfGPDxnOdsL4FtqzVew+GfFzjhxvlXugK2dpZ6nHB05T3a8WP5VE6Ai24xbWz5fN9zD6Z0vj9MWUbWzpp1NvPUa67mZIH1Xe4b5WeLAzDW7Z6u8z+yslorT0+naDwaiQuc45I6N8h+6AA5ddigACIAAiAAIgACJt8b/Bg5aN0/LLvNO1j+Jl3W3lM4DIgqpqbPgvLcjBwcZHZY1RR09Xw+OwO4TkZGcHuFSKUUowioJdNo9j4q0aFaLjWt6dRPvzLc9AeAcQchZBaCMFR/xG0hiVp+4ydrbqFzB+VxXQhpKXKuZebbr9zpTUGOllcRWsIPZ1ERJPhDnnUnJXcdm+hLeitR08FE+G4TYIdtxdu3ooR/UDSlVU3Bk9spyQW+9wgc88z5rRtn7GX0rjaeUzVva1ot03Nc32Nh/lDnv+2jP6J4cZPB5V3t9WU4LsjpLnqi2to5DBOC/BxjnlcnaNHXd9fCKmmcGcQyTjGPNb7j9P4jFJQtLOm9kusluzILotorlXsir6vf42BAks0k7uOVxJ7ndWWhgip28ELQ0DoBhWWUxFhmbaVpf0IyhL823U+MLgsbgLZ2uMoqMH1cvUyAPsVU4h9n4zwZzjO2fReZo6cz+1Fg8TGOLG+O2UABjrJQABEAARAAEQABEAARAAEQABEHUAInUABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEQABEAARAAEX/2Q==" };
  function b64bytes(b){
    if(typeof atob==="function"){ const s=atob(b); const u=new Uint8Array(s.length);
      for(let i=0;i<s.length;i++) u[i]=s.charCodeAt(i); return u; }
    return new Uint8Array(Buffer.from(b,"base64"));
  }
  "use strict";
  // Helvetica advance widths (units/1000) for ASCII 32..126
  const W=[278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,
  556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,
  556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,
  500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,
  500,334,260,334,584];
  function tw(s,size,bold){
    s=String(s==null?"":s); let t=0;
    for(let i=0;i<s.length;i++){ const c=s.charCodeAt(i);
      t += (c>=32&&c<=126)?W[c-32]:556; }
    return t/1000*size*(bold?1.06:1);
  }
  function clip(s,maxW,size,bold){
    s=String(s==null?"":s);
    if(tw(s,size,bold)<=maxW) return s;
    let lo=0,hi=s.length;
    while(lo<hi){ const m=(lo+hi+1)>>1; if(tw(s.slice(0,m)+"…",size,bold)<=maxW) lo=m; else hi=m-1; }
    return s.slice(0,lo)+"…";
  }
  function wrap(s,maxW,size,bold){
    const words=String(s==null?"":s).split(/\s+/).filter(Boolean), out=[]; let line="";
    for(const w of words){
      const t=line?line+" "+w:w;
      if(tw(t,size,bold)<=maxW) line=t;
      else { if(line) out.push(line); if(tw(w,size,bold)>maxW){ out.push(clip(w,maxW,size,bold)); line=""; } else line=w; }
    }
    if(line) out.push(line);
    return out.length?out:[""];
  }
  const pesc=s=>String(s==null?"":s).replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)")
    // PDF WinAnsi: map the few non-ASCII glyphs we use
    .replace(/—/g,"-").replace(/–/g,"-").replace(/→/g,"->").replace(/↔/g,"<->")
    .replace(/•/g,"-").replace(/…/g,"...").replace(/×/g,"x").replace(/’/g,"'")
    .replace(/“|”/g,'"').replace(/≤/g,"<=").replace(/[^\x20-\x7E]/g,"");

  function build(doc){
    const land=doc.landscape!==false;
    const PW=land?842:595, PH=land?595:842;
    const M=36, CW=PW-M*2;
    const pages=[]; let ops=[], y=0;
    const F={reg:"F1",bold:"F2"};
    function newPage(){ if(ops.length) pages.push(ops); ops=[]; y=PH-M; }
    function need(h){ if(y-h<M+18) newPage(); }
    function text(s,x,yy,size,bold,rgb){
      ops.push(`BT /${bold?F.bold:F.reg} ${size} Tf ${rgb||"0.16 0.18 0.21"} rg 1 0 0 1 ${x.toFixed(1)} ${yy.toFixed(1)} Tm (${pesc(s)}) Tj ET`);
    }
    function rect(x,yy,w,h,rgb){ ops.push(`${rgb} rg ${x.toFixed(1)} ${yy.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)} re f`); }
    function line(x1,yy,x2,rgb){ ops.push(`${rgb||"0.85 0.87 0.90"} RG 0.6 w ${x1.toFixed(1)} ${yy.toFixed(1)} m ${x2.toFixed(1)} ${yy.toFixed(1)} l S`); }

    newPage();
    // ---- header ----
    text(doc.title||"Report",M,y-14,17,true,"0.12 0.16 0.27"); y-=22;
    if(doc.subtitle){ text(doc.subtitle,M,y-10,9.5,false,"0.42 0.46 0.52"); y-=14; }
    if(doc.meta&&doc.meta.length){
      y-=4;
      const colW=CW/2;
      doc.meta.forEach((kv,i)=>{
        const cx=M+(i%2)*colW;
        if(i%2===0&&i>0) y-=11;
        text(String(kv[0]),cx,y-8,8,true,"0.42 0.46 0.52");
        text(clip(kv[1],colW-96,8,false),cx+92,y-8,8,false,"0.20 0.22 0.26");
      });
      y-=16;
    }
    line(M,y,PW-M); y-=16;

    (doc.blocks||[]).forEach(b=>{
      if(b.t==="space"){ y-=(b.h||10); return; }
      if(b.t==="rule"){ need(10); line(M,y,PW-M); y-=10; return; }
      if(b.t==="h1"){
        need(40); y-=10;
        rect(M,y-15,3.2,17,"0.96 0.51 0.12");            // Burn accent bar
        text(b.v,M+9,y-12,14.5,true,"0.09 0.13 0.22");
        y-=25; return; }
      if(b.t==="h2"){
        need(30); y-=4;
        text(b.v,M,y-10,11,true,"0.20 0.28 0.40");
        line(M,y-14,PW-M,"0.86 0.89 0.93");               // hairline under each subsection
        y-=21; return; }
      if(b.t==="p"){
        const size=b.size||9.5, lines=wrap(b.v,CW-(b.indent||0),size,false);
        lines.forEach(ln=>{ need(size+5); text(ln,M+(b.indent||0),y-size,size,false,b.rgb); y-=size+3.5; });
        y-=3; return;
      }
      if(b.t==="band"){
        /* The outcome stated once, plainly, before any detail. A reader who goes
           no further should still know the answer. */
        const h=b.h||46, fill=b.fill||"0.16 0.22 0.33";
        need(h+8);
        rect(M,y-h,CW,h,fill);
        rect(M,y-h,4,h,b.edge||"0.96 0.51 0.12");
        text(String(b.v||""),M+16,y-19,15.5,true,"1 1 1");
        if(b.sub) text(clip(b.sub,CW-200,9.5,false),M+16,y-34,9.5,false,"0.86 0.89 0.93");
        if(b.right){
          const rw=tw(String(b.right),19,true);
          text(String(b.right),M+CW-16-rw,y-24,19,true,"1 1 1");
          if(b.rightSub){ const sw2=tw(String(b.rightSub),8,false);
            text(String(b.rightSub),M+CW-16-sw2,y-36,8,false,"0.80 0.84 0.89"); }
        }
        y-=h+12; return;
      }
      if(b.t==="kv"){
        (b.rows||[]).forEach(r=>{ need(13);
          text(String(r[0]),M,y-9,9,true,"0.42 0.46 0.52");
          text(clip(r[1],CW-140,9,false),M+136,y-9,9,false); y-=13; });
        y-=4; return;
      }
      if(b.t==="table"){
        const cols=b.cols||[], size=b.size||8.2, pad=5, rowH=b.rowH||14.5;
        const total=cols.reduce((a,c)=>a+(c.w||60),0);
        const scale=total>CW?CW/total:1;
        const widths=cols.map(c=>(c.w||60)*scale);
        const drawHead=()=>{
          need(rowH+6);
          rect(M,y-rowH+3,CW,rowH,"0.16 0.22 0.33");
          let x=M;
          cols.forEach((c,i)=>{ text(clip(c.h,widths[i]-pad*2,size,true),x+pad,y-rowH+7.5,size,true,"1 1 1"); x+=widths[i]; });
          y-=rowH+1;
        };
        drawHead();
        (b.rows||[]).forEach((r,ri)=>{
          // wrap the widest text cell to keep rows readable
          let hLines=1;
          const cellLines=r.map((cell,i)=>{
            const v=(cell&&typeof cell==="object")?cell.v:cell;
            if(cols[i]&&cols[i].wrap){ const L=wrap(v,widths[i]-pad*2,size,false); if(L.length>hLines) hLines=Math.min(L.length,4); return L.slice(0,4); }
            return [clip(v,widths[i]-pad*2,size,false)];
          });
          const h=rowH+(hLines-1)*(size+2);
          if(y-h<M+18){ newPage(); drawHead(); }
          if(ri%2===1) rect(M,y-h+3,CW,h,"0.975 0.980 0.988");
          let x=M;
          r.forEach((cell,i)=>{
            const o=(cell&&typeof cell==="object")?cell:{v:cell};
            const rgb=o.rgb||"0.16 0.18 0.21";
            (cellLines[i]||[""]).forEach((ln,li)=>{
              const tx=(cols[i]&&cols[i].align==="r")?x+widths[i]-pad-tw(ln,size,!!o.b):x+pad;
              text(ln,tx,y-rowH+7.5-li*(size+2),size,!!o.b,rgb);
            });
            x+=widths[i];
          });
          y-=h; line(M,y+2,PW-M,"0.915 0.930 0.945");
        });
        y-=8; return;
      }
    });
    pages.push(ops);

    // ---- assemble PDF ----
    const enc=new TextEncoder();
    const objs=[]; const add=s=>{ objs.push(s); return objs.length; };
    const nPages=pages.length;
    const fontReg=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
    const fontBold=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
    const logoBytes=b64bytes(LOGO.b64);
    const markBytes=b64bytes(MARK.b64);
    const logoId=add({ __bin:true, bin:logoBytes,
      head:`<< /Type /XObject /Subtype /Image /Width ${LOGO.w} /Height ${LOGO.h} `
        +`/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${logoBytes.length} >>\nstream\n` });
    const markId=add({ __bin:true, bin:markBytes,
      head:`<< /Type /XObject /Subtype /Image /Width ${MARK.w} /Height ${MARK.h} `
        +`/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${markBytes.length} >>\nstream\n` });
    const pagesId=objs.length+1+nPages*2;   // reserve page + content objs
    const pageIds=[];
    pages.forEach((o,i)=>{
      const foot=`BT /F1 7.5 Tf 0.55 0.58 0.62 rg 1 0 0 1 ${(PW-M-60).toFixed(1)} ${(M-10).toFixed(1)} Tm (Page ${i+1} of ${nPages}) Tj ET`
        +(doc.footer?`\nBT /F1 7.5 Tf 0.58 0.61 0.65 rg 1 0 0 1 ${M.toFixed(1)} ${(M-10).toFixed(1)} Tm (${pesc(String(doc.footer).slice(0,120))}) Tj ET`:"")
        +`\n0.90 0.92 0.94 RG 0.5 w ${M.toFixed(1)} ${(M-4).toFixed(1)} m ${(PW-M).toFixed(1)} ${(M-4).toFixed(1)} l S`;
      // both marks, bottom-left of every page: the Burn logo as supplied, then the system name
      // Burn logo at the extreme top left, the system wordmark at the extreme top right
      const lw=66, lh=lw*LOGO.h/LOGO.w, ly=PH-M+2;
      const bW=tw("BURN",9.5,true), rW=tw(" Recon",9.5,false);
      /* The mark sits immediately left of the wordmark, squared and sized to the
         cap height of the text beside it so the pair reads as one lockup. */
      const mk=15, mgap=6;
      const rx=PW-M-bW-rW;
      const mx=rx-mk-mgap;
      const brand=`q ${lw} 0 0 ${lh.toFixed(1)} ${M} ${ly.toFixed(1)} cm /Im0 Do Q`
        +`\nq ${mk} 0 0 ${mk} ${mx.toFixed(1)} ${(ly+1).toFixed(1)} cm /Im1 Do Q`
        +`\nBT /F2 9.5 Tf 0.96 0.51 0.12 rg 1 0 0 1 ${rx.toFixed(1)} ${(ly+5).toFixed(1)} Tm (BURN) Tj ET`
        +`\nBT /F1 9.5 Tf 0.42 0.46 0.51 rg 1 0 0 1 ${(rx+bW+2).toFixed(1)} ${(ly+5).toFixed(1)} Tm (Recon) Tj ET`;
      const stream=o.concat([foot,brand]).join("\n");
      const cid=add(`<< /Length ${enc.encode(stream).length} >>\nstream\n${stream}\nendstream`);
      const pid=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /Font << /F1 ${fontReg} 0 R /F2 ${fontBold} 0 R >> /XObject << /Im0 ${logoId} 0 R /Im1 ${markId} 0 R >> >> /Contents ${cid} 0 R >>`);
      pageIds.push(pid);
    });
    const realPages=add(`<< /Type /Pages /Kids [${pageIds.map(i=>i+" 0 R").join(" ")}] /Count ${nPages} >>`);
    const catalog=add(`<< /Type /Catalog /Pages ${realPages} 0 R >>`);
    // fix parent refs
    for(let i=0;i<objs.length;i++){ if(typeof objs[i]!=="string") continue;   // skip binary objects
      objs[i]=objs[i].replace(/\/Parent \d+ 0 R/,`/Parent ${realPages} 0 R`); }

    // Byte-accurate assembly: offsets must count bytes, and an embedded image
    // stream is raw binary, so text and binary are concatenated as byte chunks.
    const lat=s=>{ const u=new Uint8Array(s.length);
      for(let i=0;i<s.length;i++) u[i]=s.charCodeAt(i)&0xFF; return u; };
    const parts=[]; let len=0;
    const put=x=>{ const u=(typeof x==="string")?lat(x):x; parts.push(u); len+=u.length; };
    put("%PDF-1.4\n");
    const offs=[];
    objs.forEach((o,i)=>{
      offs.push(len);
      put(`${i+1} 0 obj\n`);
      if(o&&o.__bin){ put(o.head); put(o.bin); put("\nendstream"); }
      else put(o);
      put("\nendobj\n");
    });
    const xref=len;
    put(`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`);
    offs.forEach(o=>put(String(o).padStart(10,"0")+" 00000 n \n"));
    put(`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
    const outU=new Uint8Array(len); let at=0;
    parts.forEach(u=>{ outU.set(u,at); at+=u.length; });
    return outU;
  }
  const API={ build, textWidth:tw, wrapText:wrap, LOGO };
  if(typeof module!=="undefined"&&module.exports) module.exports=API;
  root.PDFWRITE=API;
})(typeof window!=="undefined"?window:this);

