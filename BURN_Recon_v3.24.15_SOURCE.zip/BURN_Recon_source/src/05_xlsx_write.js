
/* Minimal offline .xlsx writer (OOXML + fflate). Multi-sheet, styled.
   build([{name, cols:[{w}], freeze:"A2", filter:true, rows:[[{v,s,n}|value,...]]}]) -> Uint8Array
   Style keys: title, sub, hdr, cell, num, bold, ok, warn, bad, crit, muted, wrap        */
(function (root) {
  "use strict";
  const esc=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,"");
  const col=n=>{let s="";n++;while(n>0){const m=(n-1)%26;s=String.fromCharCode(65+m)+s;n=(n-(m+1))/26;}return s;};

  // fills / fonts / xf indices are fixed by construction order below
  /* brand sits last on purpose: appending keeps every existing index stable, and a
   shifted index does not fail loudly — it silently paints the wrong cells. */
  const STYLE={ cell:1, hdr:2, title:3, num:4, bold:5, ok:6, warn:7, bad:8, sub:9, muted:10, crit:11, wrap:12, brand:13 };

  function styles(){
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.#####"/></numFmts>
<fonts count="8">
<font><sz val="10"/><name val="Calibri"/></font>
<font><sz val="10"/><name val="Calibri"/><b/><color rgb="FFFFFFFF"/></font>
<font><sz val="15"/><name val="Calibri"/><b/><color rgb="FF1F2A44"/></font>
<font><sz val="10"/><name val="Calibri"/><b/></font>
<font><sz val="9"/><name val="Calibri"/><color rgb="FF6B7280"/></font>
<font><sz val="11"/><name val="Calibri"/><b/><color rgb="FF1F2A44"/></font>
<font><sz val="10"/><name val="Calibri"/><color rgb="FF9C2A1A"/></font>
<font><sz val="12"/><name val="Calibri"/><b/><color rgb="FFFFFFFF"/></font>
</fonts>
<fills count="8">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF1F2A44"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE7F5EC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFCF3D6"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFCE8EA"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF6D5CD"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF96A1B"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFD9DEE7"/></left><right style="thin"><color rgb="FFD9DEE7"/></right>
<top style="thin"><color rgb="FFD9DEE7"/></top><bottom style="thin"><color rgb="FFD9DEE7"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="14">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFill="1" applyBorder="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="5" borderId="1" xfId="0" applyFill="1" applyBorder="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="6" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="0" fontId="7" fillId="7" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment vertical="center"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;
  }

  function sheetXml(sh){
    /* A banner row in the mark's own orange, so a workbook opened three months
       from now is identifiably from this system. The mark itself is not embedded:
       an image in xlsx needs a media part, a drawing part and three more
       relationships, and getting any of them wrong produces a file Excel refuses
       to open. A wrong colour is a blemish; an unopenable workbook loses the work. */
    const banner=(sh.banner===false)?null:[
      {v:"BURN Recon  \u2014  "+(sh.name||"report"),s:"brand"}];
    const rows=banner?[banner].concat(sh.rows||[]):(sh.rows||[]);
    /* The banner pushes every row down by one, so the frozen pane and the
       autofilter have to move with it — otherwise the sheet freezes the banner
       and filters on the header row, and nobody notices until they try to sort. */
    const shift=banner?1:0;
    let maxC=0; rows.forEach(r=>{ if(r&&r.length>maxC) maxC=r.length; });
    const colsXml=(sh.cols&&sh.cols.length)
      ? "<cols>"+sh.cols.map((c,i)=>`<col min="${i+1}" max="${i+1}" width="${c.w||12}" customWidth="1"/>`).join("")+"</cols>"
      : "";
    const pane="<sheetViews>"+(sh.freeze
      ? `<sheetView workbookViewId="0" showGridLines="0"><pane ySplit="${(parseInt(String(sh.freeze).replace(/\D/g,""),10)||2)+shift-1}" topLeftCell="${sh.freeze}" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft"/></sheetView>`
      : `<sheetView workbookViewId="0" showGridLines="0"/>`)+"</sheetViews>";
    let body="";
    rows.forEach((r,ri)=>{
      if(!r){ return; }
      let cells="";
      r.forEach((cell,ci)=>{
        if(cell===null||cell===undefined||cell==="") return;
        const o=(typeof cell==="object"&&cell!==null&&!(cell instanceof Date))?cell:{v:cell};
        const ref=col(ci)+(ri+1);
        const st=o.s?(STYLE[o.s]||0):0;
        const isNum=(o.n===true)||(o.n!==false&&typeof o.v==="number"&&isFinite(o.v));
        if(isNum&&o.v!==""&&o.v!==null&&isFinite(Number(o.v)))
          cells+=`<c r="${ref}" s="${st||STYLE.num}"><v>${Number(o.v)}</v></c>`;
        else
          cells+=`<c r="${ref}" s="${st}" t="inlineStr"><is><t xml:space="preserve">${esc(o.v)}</t></is></c>`;
      });
      if(cells) body+=`<row r="${ri+1}"${sh.rowH&&sh.rowH[ri]?` ht="${sh.rowH[ri]}" customHeight="1"`:""}>${cells}</row>`;
    });
    const filter=(sh.filter&&rows.length>1)
      ?`<autoFilter ref="A${(sh.filterRow||1)+shift}:${col(maxC-1)}${rows.length}"/>`:"";
    /* Dropdown cells, so a supervisor picks from a list instead of typing free
       text that nobody can total afterwards. sh.validations is a list of
       {range,values} \u2014 the range in A1 notation, the values as plain strings. */
    const dv=(sh.validations||[]).map(v=>
      `<dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="1"`
      +` sqref="${esc(v.range)}"><formula1>"${esc((v.values||[]).join(","))}"</formula1></dataValidation>`
    ).join("");
    const dvXml=dv?`<dataValidations count="${(sh.validations||[]).length}">${dv}</dataValidations>`:"";
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${pane}<sheetFormatPr defaultRowHeight="14.5"/>${colsXml}<sheetData>${body}</sheetData>${filter}${dvXml}<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>`;
  }

  function build(sheets,deps){
    const zipLib=(deps&&deps.fflate)||root.fflate;
    if(!zipLib||!zipLib.zipSync) throw new Error("zip library unavailable");
    const enc=new TextEncoder();
    const names=sheets.map((s,i)=>(s.name||("Sheet"+(i+1))).replace(/[\\\/\?\*\[\]:]/g,"-").slice(0,31));
    const files={};
    files["[Content_Types].xml"]=enc.encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
${sheets.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}
</Types>`);
    files["_rels/.rels"]=enc.encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`);
    files["xl/workbook.xml"]=enc.encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>${names.map((n,i)=>`<sheet name="${esc(n)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join("")}</sheets></workbook>`);
    files["xl/_rels/workbook.xml.rels"]=enc.encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${sheets.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join("")}
<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`);
    files["xl/styles.xml"]=enc.encode(styles());
    sheets.forEach((sh,i)=>{ files["xl/worksheets/sheet"+(i+1)+".xml"]=enc.encode(sheetXml(sh)); });
    return zipLib.zipSync(files,{level:6});
  }
  const API={ build, STYLE };
  if(typeof module!=="undefined"&&module.exports) module.exports=API;
  root.XLSXWRITE=API;
})(typeof window!=="undefined"?window:this);

